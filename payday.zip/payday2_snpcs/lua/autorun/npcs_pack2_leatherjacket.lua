-- Friendly --

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 01 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_01_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 02 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_02_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 03 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_03_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 04 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_04_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 05 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_05_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 06 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_06_f", NPC )


local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 07 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_07_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 08 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_08_f", NPC )

local Category = "Smalls Civilian Pack 2 | Leather Jacket Male"

local NPC = {
	Name = "Male 09 Leather Jacket F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_leather_jacket_male_09_f", NPC )


-- Randomize Bodygroups Leather Jacket Male --

local smallsciviliansmodels_pack2_leather_jacket = {
	"models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_npc.mdl",
	"models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_npc.mdl"
}

hook.Add( "PlayerSpawnedNPC", "RandomLeatherJacketkBodygroups", function(ply,npc)
		if table.HasValue( smallsciviliansmodels_pack2_leather_jacket, npc:GetModel() ) then
			npc:SetBodygroup( 1, math.random(0,8) );
			npc:SetBodygroup( 2, math.random(0,4) );
			npc:SetBodygroup( 3, math.random(0,3) );
			npc:SetBodygroup( 4, math.random(0,3) );
		end
end)