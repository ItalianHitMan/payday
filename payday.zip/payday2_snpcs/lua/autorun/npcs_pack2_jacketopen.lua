-- Friendly --

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 01 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_01_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 02 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_02_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 03 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_03_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 04 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_04_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 05 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_05_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 06 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_06_f", NPC )


local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 07 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_07_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 08 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_08_f", NPC )

local Category = "Smalls Civilian Pack 2 | Jacket Jeans Male"

local NPC = {
	Name = "Male 09 Jacket Open F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_jacketopen_male_09_f", NPC )


-- Randomize Bodygroups Jacket Open Male --

local smallsciviliansmodels_pack2_jacketopen = {
	"models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_npc.mdl",
	"models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_npc.mdl"
}

hook.Add( "PlayerSpawnedNPC", "RandomJacketOpenBodygroups", function(ply,npc)
		if table.HasValue( smallsciviliansmodels_pack2_jacketopen, npc:GetModel() ) then
			npc:SetBodygroup( 1, math.random(0,3) );
			npc:SetBodygroup( 2, math.random(0,1) );
			npc:SetBodygroup( 3, math.random(0,7) );
			npc:SetBodygroup( 4, math.random(0,9) );
		end
end)