/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2019 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = "Left 4 Dead Human SNPCs"
local AddonName = "Left 4 Dead Humans"
local AddonType = "SNPCs & Weapons"
local AutorunFile = "autorun/vj_l4dhumans_autorun.lua"
-------------------------------------------------------
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')

	local vCat = "PAYDAY 2 Intros" -- Category, you can also set a category individually by replacing the vCat with a string value
    VJ.AddNPC("Blue S.W.A.T (Rappel)","npc_vj_payday2_rappel_swat",vCat) 
    VJ.AddNPC("Blue S.W.A.T Shield (Rappel)","npc_vj_payday2_rappel_swat_shield",vCat) 
    VJ.AddNPC("Bulldozer (Rappel)","npc_vj_payday2_rappel_bulldozer",vCat) 
    VJ.AddNPC("Bulldozer Pyro (Rappel)","npc_vj_payday2_rappel_bulldozer_pyro",vCat) 
    VJ.AddNPC("Bulldozer Saiga12k (Rappel)","npc_vj_payday2_rappel_bulldozer_saiga12k",vCat) 
    VJ.AddNPC("Bulldozer Frag (Rappel)","npc_vj_payday2_rappel_bulldozer_frag",vCat) 
    VJ.AddNPC("Bulldozer SAW (Rappel)","npc_vj_payday2_rappel_bulldozer_saw",vCat) 
    VJ.AddNPC("Bulldozer Medic (Rappel)","npc_vj_payday2_rappel_bulldozer_medic",vCat) 
    VJ.AddNPC("Bulldozer Minigun (Rappel)","npc_vj_payday2_rappel_bulldozer_minigun",vCat) 
    VJ.AddNPC("Bulldozer Shield (Rappel)","npc_vj_payday2_rappel_bulldozer_shield",vCat) 
    VJ.AddNPC("Heavy S.W.A.T (Rappel)","npc_vj_payday2_rappel_heavy_swat",vCat) 
    VJ.AddNPC("Heavy S.W.A.T Shield (Rappel)","npc_vj_payday2_rappel_heavy_swat_shield",vCat) 
    VJ.AddNPC("FBI (Rappel)","npc_vj_payday2_rappel_fbi",vCat) 
    VJ.AddNPC("FBI Agent (Rappel)","npc_vj_payday2_rappel_fbi_agent",vCat) 
    VJ.AddNPC("FBI Shield (Rappel)","npc_vj_payday2_rappel_fbi_shield",vCat) 
    VJ.AddNPC("Heavy FBI (Rappel)","npc_vj_payday2_rappel_heavy_fbi",vCat) 
    VJ.AddNPC("Heavy FBI Shield (Rappel)","npc_vj_payday2_rappel_heavy_fbi_shield",vCat) 
    VJ.AddNPC("S.W.A.T Taser (Rappel)","npc_vj_payday2_rappel_taser",vCat) 
    VJ.AddNPC("S.W.A.T Medic (Rappel)","npc_vj_payday2_rappel_medic",vCat) 
    VJ.AddNPC("Cloaker (Rappel)","npc_vj_payday2_rappel_cloaker",vCat) 
    VJ.AddNPC("Zeal S.W.A.T (Rappel)","npc_vj_payday2_rappel_zeal_swat",vCat) 
    VJ.AddNPC("Zeal S.W.A.T Shotgunner (Rappel)","npc_vj_payday2_rappel_zeal_swat_shotgunner",vCat) 
    VJ.AddNPC("Zeal S.W.A.T Shield (Rappel)","npc_vj_payday2_rappel_zeal_swat_shield",vCat) 
    VJ.AddNPC("Zeal S.W.A.T Heavy (Rappel)","npc_vj_payday2_rappel_heavy_zeal_swat",vCat) 
    VJ.AddNPC("Zeal Taser (Rappel)","npc_vj_payday2_rappel_zeal_taser",vCat) 
    VJ.AddNPC("Zeal Bulldozer (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer",vCat) 
    VJ.AddNPC("Zeal Bulldozer Saiga12k (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_saiga12k",vCat) 
    VJ.AddNPC("Zeal Bulldozer Frag (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_frag",vCat) 
    VJ.AddNPC("Zeal Bulldozer SAW (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_saw",vCat) 
    VJ.AddNPC("Zeal Bulldozer Medic (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_medic",vCat) 
    VJ.AddNPC("Zeal Bulldozer Minigun (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_minigun",vCat) 
    VJ.AddNPC("Zeal Bulldozer Shield (Rappel)","npc_vj_payday2_rappel_zeal_bulldozer_shield",vCat) 
    VJ.AddNPC("Zeal Cloaker (Rappel)","npc_vj_payday2_rappel_zeal_cloaker",vCat) 
	
-- !!!!!! DON'T TOUCH ANYTHING BELOW THIS !!!!!! -------------------------------------------------------------------------------------------------------------------------
	AddCSLuaFile(AutorunFile)
	VJ.AddAddonProperty(AddonName,AddonType)
else
	if (CLIENT) then
		chat.AddText(Color(0,200,200),PublicAddonName,
		Color(0,255,0)," was unable to install, you are missing ",
		Color(255,100,0),"VJ Base!")
	end
	timer.Simple(1,function()
		if not VJF then
			if (CLIENT) then
				VJF = vgui.Create("DFrame")
				VJF:SetTitle("ERROR!")
				VJF:SetSize(790,560)
				VJF:SetPos((ScrW()-VJF:GetWide())/2,(ScrH()-VJF:GetTall())/2)
				VJF:MakePopup()
				VJF.Paint = function()
					draw.RoundedBox(8,0,0,VJF:GetWide(),VJF:GetTall(),Color(200,0,0,150))
				end
				
				local VJURL = vgui.Create("DHTML",VJF)
				VJURL:SetPos(VJF:GetWide()*0.005, VJF:GetTall()*0.03)
				VJURL:Dock(FILL)
				VJURL:SetAllowLua(true)
				VJURL:OpenURL("https://sites.google.com/site/vrejgaming/vjbasemissing")
			elseif (SERVER) then
				timer.Create("VJBASEMissing",5,0,function() print("VJ Base is Missing! Download it from the workshop!") end)
			end
		end
	end)
end