/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2019 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = "Left 4 Dead Human SNPCs"
local AddonName = "Left 4 Dead Humans"
local AddonType = "SNPCs & Weapons"
local AutorunFile = "autorun/vj_l4dhumans_autorun.lua"
-------------------------------------------------------
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')

	local vCat = "PAYDAY 2 Zombies" -- Category, you can also set a category individually by replacing the vCat with a string value
    VJ.AddNPC_HUMAN("Blue Z.W.A.T","npc_vj_payday2_swat_zombie",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Blue Z.W.A.T Zhield","npc_vj_payday2_swat_shield_zombie",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Heavy Z.W.A.T","npc_vj_payday2_heavy_swat_zombie",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Heavy Z.W.A.T Zhield","npc_vj_payday2_heavy_swat_shield_zombie",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Zloaker","npc_vj_payday2_cloaker_zombie",{"weapon_vj_payday_cmp"},vCat)
    VJ.AddNPC_HUMAN("Medic","npc_vj_payday2_medic_zombie",{"weapon_vj_payday_locomotive","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Tazer","npc_vj_payday2_taser_zombie",{"weapon_vj_payday_taser"},vCat)
    VJ.AddNPC_HUMAN("Zulldozer","npc_vj_payday2_bulldozer_zombie",{"weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Zulldozer Saiga12k","npc_vj_payday2_bulldozer_zombie_saiga12k",{"weapon_vj_payday_saiga12k"},vCat)
    VJ.AddNPC_HUMAN("Zulldozer SAW","npc_vj_payday2_bulldozer_zombie_saw",{"weapon_vj_payday_dozer"},vCat)
    VJ.AddNPC_HUMAN("Zulldozer Headless","npc_vj_payday2_bulldozer_headless",{"weapon_vj_payday_dozer"},vCat)
    VJ.AddNPC_HUMAN("Blue Z.W.A.T Zniper","npc_vj_payday2_swat_sniper_policia",{"weapon_vj_payday_sniper_rifle"},vCat)
    VJ.AddNPC_HUMAN("Zolice Officer","npc_vj_payday2_police_zombie",{"weapon_vj_payday_pistol","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Zolice Officer Armored","npc_vj_payday2_police_armour_zombie",{"weapon_vj_payday_pistol","weapon_vj_payday_bronco","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Zolice Chief","npc_vj_payday2_police_chief_zombie",{"weapon_vj_payday_locomotive","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Heavy ZBI","npc_vj_payday2_heavy_fbi_zombie",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("Heavy ZBI Zhield","npc_vj_payday2_heavy_fbi_shield_zombie",{"weapon_vj_payday_cmp_shield"},vCat)
    VJ.AddNPC_HUMAN("ZBI","npc_vj_payday2_fbi_zombie",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("ZBI Zhield","npc_vj_payday2_fbi_shield_zombie",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("ZBI Zniper","npc_vj_payday2_fbi_sniper_zombie",{"weapon_vj_payday_sniper_rifle"},vCat)
    VJ.AddNPC_HUMAN("Skull Hunter","npc_vj_payday2_skull_hunter",{"weapon_vj_payday_reinfield","weapon_vj_payday_saiga12k"},vCat)
	
-- !!!!!! DON'T TOUCH ANYTHING BELOW THIS !!!!!! -------------------------------------------------------------------------------------------------------------------------
	AddCSLuaFile(AutorunFile)
	VJ.AddAddonProperty(AddonName,AddonType)
else
	if (CLIENT) then
		chat.AddText(Color(0,200,200),PublicAddonName,
		Color(0,255,0)," was unable to install, you are missing ",
		Color(255,100,0),"VJ Base!")
	end
	timer.Simple(1,function()
		if not VJF then
			if (CLIENT) then
				VJF = vgui.Create("DFrame")
				VJF:SetTitle("ERROR!")
				VJF:SetSize(790,560)
				VJF:SetPos((ScrW()-VJF:GetWide())/2,(ScrH()-VJF:GetTall())/2)
				VJF:MakePopup()
				VJF.Paint = function()
					draw.RoundedBox(8,0,0,VJF:GetWide(),VJF:GetTall(),Color(200,0,0,150))
				end
				
				local VJURL = vgui.Create("DHTML",VJF)
				VJURL:SetPos(VJF:GetWide()*0.005, VJF:GetTall()*0.03)
				VJURL:Dock(FILL)
				VJURL:SetAllowLua(true)
				VJURL:OpenURL("https://sites.google.com/site/vrejgaming/vjbasemissing")
			elseif (SERVER) then
				timer.Create("VJBASEMissing",5,0,function() print("VJ Base is Missing! Download it from the workshop!") end)
			end
		end
	end)
end