-- Friendly ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 01 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_01_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 02 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_02_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 03 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_03_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 04 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_04_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 05 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_05_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 06 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_06_f", NPC )


local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 07 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_07_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 08 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_08_f", NPC )

local Category = "Smalls Civilian Pack 2 | Baseball Tee Male"

local NPC = {
	Name = "Male 09 Baseball Tee F",
	Class = "npc_citizen",
	Model = "models/smalls_civilians/pack2/male/baseballtee/male_09_baseballtee_npc.mdl",
	KeyValues = { citizentype = 4
},
	Category = Category,
	Health = "25",
	Weapons = { ""
},
}

list.Set( "NPC", "npc_baseballtee_male_09_f", NPC )


-- Randomize Bodygroups Baseball Tee Male ----------------------------------------------------------------------------------------------------------------------------------------------------

local smallsciviliansmodels_pack2_baseballtee = {
	"models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_npc.mdl",
	"models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_npc.mdl"
}

hook.Add( "PlayerSpawnedNPC", "RandomBaseballTeeBodygroups", function(ply,npc)
		if table.HasValue( smallsciviliansmodels_pack2_baseballtee, npc:GetModel() ) then
			npc:SetBodygroup( 1, math.random(0,3) );
			npc:SetBodygroup( 2, math.random(0,10) );
			npc:SetBodygroup( 3, math.random(0,10) );
		end
end)