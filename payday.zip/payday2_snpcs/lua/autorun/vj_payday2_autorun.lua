/*--------------------------------------------------
	=============== Autorun File ===============
	*** Copyright (c) 2012-2019 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
--------------------------------------------------*/
------------------ Addon Information ------------------
local PublicAddonName = "Left 4 Dead Human SNPCs"
local AddonName = "Left 4 Dead Humans"
local AddonType = "SNPCs & Weapons"
local AutorunFile = "autorun/vj_l4dhumans_autorun.lua"
-------------------------------------------------------
local VJExists = file.Exists("lua/autorun/vj_base_autorun.lua","GAME")
if VJExists == true then
	include('autorun/vj_controls.lua')

	local vCat = "PAYDAY 2" -- Category, you can also set a category individually by replacing the vCat with a string value
    VJ.AddNPC_HUMAN("Blue S.W.A.T","npc_vj_payday2_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Security Guard","npc_vj_payday2_security",{"weapon_vj_payday_pistol"},vCat)
    VJ.AddNPC_HUMAN("Blue S.W.A.T Shield","npc_vj_payday2_swat_shield",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Heavy S.W.A.T","npc_vj_payday2_heavy_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Heavy S.W.A.T Shield","npc_vj_payday2_heavy_swat_shield",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Cloaker","npc_vj_payday2_cloaker",{"weapon_vj_payday_cmp"},vCat)
    VJ.AddNPC_HUMAN("S.W.A.T Medic","npc_vj_payday2_medic",{"weapon_vj_payday_locomotive","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("S.W.A.T Taser","npc_vj_payday2_taser",{"weapon_vj_payday_taser"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer","npc_vj_payday2_bulldozer",{"weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Pyro","npc_vj_payday2_bulldozer_pyro",{"weapon_vj_payday_flamethrower_dozer"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Shield","npc_vj_payday2_bulldozer_shield",{"weapon_vj_payday_cmp"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Frag","npc_vj_payday2_bulldozer_frag",{"weapon_vj_payday_grenade_launcher"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Saiga12k","npc_vj_payday2_bulldozer_saiga12k",{"weapon_vj_payday_saiga12k"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer SAW","npc_vj_payday2_bulldozer_saw",{"weapon_vj_payday_dozer"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Medic","npc_vj_payday2_bulldozer_medic",{"weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Bulldozer Minigun","npc_vj_payday2_bulldozer_minigun",{"weapon_vj_payday_minigun"},vCat)
    VJ.AddNPC_HUMAN("Police Officer","npc_vj_payday2_police",{"weapon_vj_payday_pistol","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Police Officer Armored","npc_vj_payday2_police_armour",{"weapon_vj_payday_pistol","weapon_vj_payday_bronco","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Police Chief","npc_vj_payday2_police_chief",{"weapon_vj_payday_locomotive","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("FBI","npc_vj_payday2_fbi",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("FBI Shield","npc_vj_payday2_fbi_shield",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Gensec Officer","npc_vj_payday2_gensec",{"weapon_vj_payday_bronco","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("Gensec S.W.A.T Shield","npc_vj_payday2_gensec_swat_shield",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("Gensec S.W.A.T","npc_vj_payday2_gensec_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Gensec Sniper","npc_vj_payday2_gensec_sniper",{"weapon_vj_payday_sniper_rifle"},vCat)
    VJ.AddNPC_HUMAN("Heavy Gensec S.W.A.T","npc_vj_payday2_heavy_gensec_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Heavy Gensec S.W.A.T Shield","npc_vj_payday2_heavy_gensec_swat_shield",{"weapon_vj_payday_cmp_shield"},vCat)
    VJ.AddNPC_HUMAN("FBI Pyro","npc_vj_payday2_pyro",{"weapon_vj_payday_flamethrower"},vCat)
    VJ.AddNPC_HUMAN("FBI Pyro Shield","npc_vj_payday2_pyro_shield",{"weapon_vj_payday_flamethrower_shield"},vCat)
    VJ.AddNPC_HUMAN("FBI Sniper","npc_vj_payday2_fbi_sniper",{"weapon_vj_payday_sniper_rifle"},vCat)
    VJ.AddNPC_HUMAN("FBI Field Agent","npc_vj_payday2_fbi_agent",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("FBI Veteran Agent","npc_vj_payday2_fbi_agent_vet",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("Hostage Resuce Team","npc_vj_payday2_hostage_rescue_team",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("Blue S.W.A.T Sniper","npc_vj_payday2_swat_sniper",{"weapon_vj_payday_sniper_rifle"},vCat)
    VJ.AddNPC_HUMAN("Heavy FBI","npc_vj_payday2_heavy_fbi",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_locomotive"},vCat)
    VJ.AddNPC_HUMAN("Heavy FBI Shield","npc_vj_payday2_heavy_fbi_shield",{"weapon_vj_payday_cmp_shield"},vCat)
    VJ.AddNPC_HUMAN("Zeal S.W.A.T","npc_vj_payday2_zeal_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16"},vCat)
    VJ.AddNPC_HUMAN("Zeal S.W.A.T Shotgunner","npc_vj_payday2_zeal_swat_shotgunner",{"weapon_vj_payday_reinfield","weapon_vj_payday_saiga12k"},vCat)
    VJ.AddNPC_HUMAN("Zeal S.W.A.T Shield","npc_vj_payday2_zeal_swat_shield",{"weapon_vj_payday_cmp_shield"},vCat)
    VJ.AddNPC_HUMAN("Zeal S.W.A.T Heavy","npc_vj_payday2_heavy_zeal_swat",{"weapon_vj_payday_ak","weapon_vj_payday_ak5","weapon_vj_payday_m16","weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer","npc_vj_payday2_zeal_bulldozer",{"weapon_vj_payday_reinfield"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer Frag","npc_vj_payday2_zeal_bulldozer_frag",{"weapon_vj_payday_grenade_launcher"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer Saiga12k","npc_vj_payday2_zeal_bulldozer_saiga12k",{"weapon_vj_payday_saiga12k"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer SAW","npc_vj_payday2_zeal_bulldozer_saw",{"weapon_vj_payday_dozer"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer Minigun","npc_vj_payday2_zeal_bulldozer_minigun",{"weapon_vj_payday_minigun"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer Shield","npc_vj_payday2_zeal_bulldozer_shield",{"weapon_vj_payday_uzi"},vCat)
    VJ.AddNPC_HUMAN("Zeal Bulldozer Medic","npc_vj_payday2_zeal_bulldozer_medic",{"weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("Zeal Cloaker","npc_vj_payday2_zeal_cloaker",{"weapon_vj_payday_uzi"},vCat)
    VJ.AddNPC_HUMAN("Zeal Taser","npc_vj_payday2_zeal_taser",{"weapon_vj_payday_taser"},vCat)
    VJ.AddNPC_HUMAN("Captain's Dozer","npc_vj_payday2_captain_dozer",{"weapon_vj_payday_uzi"},vCat)
    VJ.AddNPC_HUMAN("Captain Winters","npc_vj_payday2_captain_winter",{"weapon_vj_payday_cmp_shield"},vCat)
    VJ.AddNPC_HUMAN("Captain's Guard","npc_vj_payday2_captain_guard",{"weapon_vj_payday_glock17"},vCat)
    VJ.AddNPC_HUMAN("LAPD Officer","npc_vj_payday2_police_angeles",{"weapon_vj_payday_pistol","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("LAPD Officer Armored","npc_vj_payday2_police_armour_angeles",{"weapon_vj_payday_pistol","weapon_vj_payday_bronco","weapon_vj_payday_mp5"},vCat)
    VJ.AddNPC_HUMAN("LAPD Chief","npc_vj_payday2_police_chief_angeles",{"weapon_vj_payday_locomotive","weapon_vj_payday_mp5"},vCat)

	
	VJ.AddNPCWeapon("VJ_PAYDAY2_AK", "weapon_vj_payday_ak") -- Adds a weapon to the NPC weapon list
    VJ.AddNPCWeapon("VJ_PAYDAY2_AK5", "weapon_vj_payday_ak5") -- Adds a weapon to the NPC weapon list
    VJ.AddNPCWeapon("VJ_PAYDAY2_SNIPER", "weapon_vj_payday_sniper_rifle") -- Adds a weapon to the NPC weapon list
	VJ.AddNPCWeapon("VJ_PAYDAY2_CMP", "weapon_vj_payday_cmp") -- Adds a weapon to the NPC weapon list
	VJ.AddNPCWeapon("VJ_PAYDAY2_CMP_SHIELD", "weapon_vj_payday_cmp_shield") -- Adds a weapon to the NPC weapon list
	VJ.AddNPCWeapon("VJ_PAYDAY2_CROSSKILL", "weapon_vj_payday_pistol") -- Adds a weapon to the NPC weapon list
	VJ.AddNPCWeapon("VJ_PAYDAY2_GLOCK", "weapon_vj_payday_glock17") -- Adds a weapon to the NPC weapon list
	VJ.AddNPCWeapon("VJ_PAYDAY2_SAW", "weapon_vj_payday_dozer")
	VJ.AddNPCWeapon("VJ_PAYDAY2_LOCOMOTIVE", "weapon_vj_payday_locomotive")
	VJ.AddNPCWeapon("VJ_PAYDAY2_UZI", "weapon_vj_payday_uzi")
	VJ.AddNPCWeapon("VJ_PAYDAY2_M16", "weapon_vj_payday_m16")
	VJ.AddNPCWeapon("VJ_PAYDAY2_MP5", "weapon_vj_payday_mp5")
	VJ.AddNPCWeapon("VJ_PAYDAY2_MINIGUN", "weapon_vj_payday_minigun")
	VJ.AddNPCWeapon("VJ_PAYDAY2_TASER", "weapon_vj_payday_taser")
	VJ.AddNPCWeapon("VJ_PAYDAY2_AKAN_TASER", "weapon_vj_payday_akan_taser")
	VJ.AddNPCWeapon("VJ_PAYDAY2_GRENADE_LAUNCHER", "weapon_vj_payday_grenade_launcher")
	VJ.AddNPCWeapon("VJ_PAYDAY2_REINFIELD", "weapon_vj_payday_reinfield")
	VJ.AddNPCWeapon("VJ_PAYDAY2_SAIGA12K", "weapon_vj_payday_saiga12k")


	
-- !!!!!! DON'T TOUCH ANYTHING BELOW THIS !!!!!! -------------------------------------------------------------------------------------------------------------------------
	AddCSLuaFile(AutorunFile)
	VJ.AddAddonProperty(AddonName,AddonType)
else
	if (CLIENT) then
		chat.AddText(Color(0,200,200),PublicAddonName,
		Color(0,255,0)," was unable to install, you are missing ",
		Color(255,100,0),"VJ Base!")
	end
	timer.Simple(1,function()
		if not VJF then
			if (CLIENT) then
				VJF = vgui.Create("DFrame")
				VJF:SetTitle("ERROR!")
				VJF:SetSize(790,560)
				VJF:SetPos((ScrW()-VJF:GetWide())/2,(ScrH()-VJF:GetTall())/2)
				VJF:MakePopup()
				VJF.Paint = function()
					draw.RoundedBox(8,0,0,VJF:GetWide(),VJF:GetTall(),Color(200,0,0,150))
				end
				
				local VJURL = vgui.Create("DHTML",VJF)
				VJURL:SetPos(VJF:GetWide()*0.005, VJF:GetTall()*0.03)
				VJURL:Dock(FILL)
				VJURL:SetAllowLua(true)
				VJURL:OpenURL("https://sites.google.com/site/vrejgaming/vjbasemissing")
			elseif (SERVER) then
				timer.Create("VJBASEMissing",5,0,function() print("VJ Base is Missing! Download it from the workshop!") end)
			end
		end
	end)
end