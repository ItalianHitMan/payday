AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/payday2/halloween_units/halloween_cloaker_rebel.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 120
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.DistanceToRunFromEnemy = 0
ENT.SightDistance = 10000000 -- How far it can see
ENT.FootStepTimeRun = 1000000000 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 1000000000 -- Next foot step sound when it is walking
ENT.Medic_SpawnPropOnHealModel = "models/payday2/equipments/first_aid_kit.mdl"
ENT.AnimTbl_IdleStand = {"Crouch_idleD"}
ENT.AnimTbl_WeaponReload = {"vjseq_crouch_reload_smg1"} -- Animations that play when the SNPC reloads
ENT.AnimTbl_WeaponReloadBehindCover = {"vjseq_crouch_reload_smg1"} -- Animations that it plays when the SNPC reloads, but behind cover
ENT.AnimTbl_WalkStand = {"walk_pistol_1"}
ENT.AnimTbl_RunStand = {"run_pistol_1"}
ENT.AnimTbl_ShootWhileMovingWalk = {"walk_pistol_1"}
ENT.AnimTbl_ShootWhileMovingRun = {"run_pistol_1"}
ENT.AnimTbl_GrenadeAttack = {ACT_RANGE_ATTACK_THROW} -- Grenade Attack Animations
ENT.GrenadeAttackAttachment = "anim_attachment_RH" -- The attachment that the grenade will spawn at, set to false to use a custom position instead
ENT.HasGrenadeAttack = true -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "cw_smoke_thrown"
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 1 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {""}
ENT.SoundTbl_MeleeAttack = {"payday2/voices/police/cloaker/afterpunch/33243064.1.mp3","payday2/voices/police/cloaker/afterpunch/516066709.1.mp3","payday2/voices/police/cloaker/afterpunch/56877676.1.mp3","payday2/voices/police/cloaker/afterpunch/67999632.1.mp3"}
ENT.SoundTbl_BeforeMeleeAttack = {"vjpayday2police/cloaker/holyshi.wav"}
ENT.SoundTbl_GrenadeAttack = {"payday2/voices/police/cloaker/afterpunch/33243064.1.mp3","payday2/voices/police/cloaker/afterpunch/516066709.1.mp3","payday2/voices/police/cloaker/afterpunch/56877676.1.mp3","payday2/voices/police/cloaker/afterpunch/67999632.1.mp3"}
ENT.SoundTbl_Pain = {"payday2/voices/police/cloaker/death/10310592.1.mp3"}
ENT.SoundTbl_Death = {"payday2/voices/police/cloaker/death/40191340.1.mp3","payday2/voices/police/cloaker/death/475828224.1.mp3","payday2/voices/police/cloaker/death/507314873.1.mp3","payday2/voices/police/cloaker/death/90031657.1.mp3"}

ENT.BeforeMeleeAttackSoundPitch1 = 100
ENT.BeforeMeleeAttackSoundPitch2 = 100

ENT.GeneralSoundPitch1 = 70
ENT.GeneralSoundPitch2 = 70

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.Helmet2 = false
ENT.Helmet1 = false
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
		self.AnimTbl_Walk = {self:GetSequenceActivity(self:LookupSequence("Crouch_walk_holding_all"))}
		self.AnimTbl_Run = {self:GetSequenceActivity(self:LookupSequence("crouch_run_holding_RPG_all"))}
		self.AnimTbl_WeaponAttack = {self:GetSequenceActivity(self:LookupSequence("crouch_shoot_smg1"))}
		self.AnimTbl_ShootWhileMovingWalk = {self:GetSequenceActivity(self:LookupSequence("Crouch_walk_aiming_all"))}
		self.AnimTbl_ShootWhileMovingRun = {self:GetSequenceActivity(self:LookupSequence("crouchRUNAIMINGALL1"))}
end
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetBodygroup(2,1)
end
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	if self.NearestPointToEnemyDistance > 20 && self.NearestPointToEnemyDistance < 270 then
		self.MeleeAttackDistance = 270
		self.MeleeAttackDamageDistance = 115
		self.AnimTbl_MeleeAttack = {"run_AR2_Relaxed_all"}
		self.TimeUntilMeleeAttackDamage = 1
		self.NextMeleeAttackTime = 3
		self.MeleeAttackDamage = 100
		self.HasMeleeAttackKnockBack = true
		self.MeleeAttackKnockBack_Forward1 = 270
		self.MeleeAttackKnockBack_Forward2 = 290
		self.MeleeAttackKnockBack_Up1 = 300
		self.MeleeAttackKnockBack_Up2 = 310
		self.MeleeAttack_NoProps = true
		self:SetSkin(1)
	end
	if self.NearestPointToEnemyDistance > 210 then
			self:SetSkin(0)
end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_CHEST then
		dmginfo:ScaleDamage(0.7)
	end
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(1.5)
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/