AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vjpayday2police/akan_dozer.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 800
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_RUSSIAN"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.SightDistance = 10000000 -- How far it can see
ENT.FootStepTimeRun = 0.5 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.AnimTbl_ShootWhileMovingRun = {ACT_WALK_AIM} -- Animations it will play when shooting while running | NOTE: Weapon may translate the animation that they see fit!
ENT.AnimTbl_MoveToCover = {ACT_WALK_AIM} -- The animation it plays when moving to a covered position
ENT.AnimTbl_Run = {ACT_WALK_AIM} -- Set the running animations | Put multiple to let the base pick a random animation when it moves
ENT.AnimTbl_Walk = {ACT_WALK_AIM} -- Set the running animations | Put multiple to let the base pick a random animation when it moves
ENT.AnimTbl_IdleStand = {ACT_IDLE_SMG1} -- If it uses normal based animation, use this
ENT.CanCrouchOnWeaponAttack = false -- Can it crouch while shooting?
ENT.AnimTbl_WeaponReloadBehindCover = {ACT_RELOAD}
ENT.GrenadeAttackAttachment = "anim_attachment_RH" -- The attachment that the grenade will spawn at, set to false to use a custom position instead
ENT.Medic_SpawnPropOnHealModel = "models/payday2/equipments/first_aid_kit.mdl"
ENT.Medic_CheckDistance = 1000 -- How far does it check for allies that are hurt? | World units
ENT.HasGrenadeAttack = false -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "obj_vj_grenade"
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 10000 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 2 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"payday2/other/1d9dc49e.mp3","payday2/other/28ca8176.mp3","payday2/other/392e7b89.mp3"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/police/medic/onhelp/123648013.english.mp3","payday2/voices/police/medic/onhelp/142637101.english.mp3","payday2/voices/police/medic/onhelp/287516577.english.mp3","payday2/voices/police/medic/onhelp/33768141.english.mp3"}
ENT.SoundTbl_OnPlayerSight = {"payday2/voices/police/bulldozer/enemyfound/bulldozer-05.mp3","payday2/voices/police/bulldozer/enemyfound/bulldozer-07.mp3","payday2/voices/police/bulldozer/enemyfound/bulldozer-17.mp3","payday2/voices/police/bulldozer/enemyfound/bulldozer-33.mp3","payday2/voices/police/bulldozer/enemyfound/bulldozer-28.mp3","bulldozer/Dozer_Against_The_Wall.wav"}
ENT.SoundTbl_Death = {"vjpayday2police/dozer/die18.wav","vjpayday2police/dozer/die1.wav","vjpayday2police/dozer/die2.wav","vjpayday2police/dozer/die20.wav","vjpayday2police/dozer/die24.wav","vjpayday2police/dozer/die26.wav","vjpayday2police/dozer/die29.wav","vjpayday2police/dozer/die31.wav","vjpayday2police/dozer/die32.wav","vjpayday2police/dozer/die9.wav"}

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.VisorGone = false
ENT.VisorBreak = false
ENT.DeadAnim = true
ENT.Visor = false
ENT.Plate = false
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
		local rand1 = math.random(1,7)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/police/bulldozer/spawn/bulldozer-06.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/police/bulldozer/spawn/bulldozer-14.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/police/bulldozer/spawn/bulldozer-18.mp3")
	end
		if rand1 == 4 then
	self:EmitSound("payday2/voices/police/bulldozer/spawn/bulldozer-19.mp3")
	end
		if rand1 == 5 then
	self:EmitSound("payday2/voices/police/bulldozer/spawn/bulldozer-22.mp3")
	end
		if rand1 == 6 then
	self:EmitSound("bulldozer/Dozer_Handle_Elites.wav")
	end
		if rand1 == 7 then
	self:EmitSound("bulldozer/Dozer_Peice_of_Me.wav")
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink() 
	if self:Health() <= 470 && self.Plate == false then
	self.Plate = true
	self:EmitSound("payday2/other/24f2ffcd.mp3")
	self:SetBodygroup(3,1)
	self:VJ_ACT_PLAYACTIVITY("vjseq_flinchhead", false, false, false, 0, {vTbl_SequenceInterruptible=false})
	end
	if self:Health() <= 167 && self.VisorGone == false then
		local rand1 = math.random(1,5)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/police/bulldozer/visorbreak/bulldozer-109.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/police/bulldozer/visorbreak/bulldozer-115.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/police/bulldozer/visorbreak/bulldozer-124.mp3")
	end
		if rand1 == 4 then
	self:EmitSound("payday2/voices/police/bulldozer/visorbreak/bulldozer-35.mp3")
	end
		if rand1 == 5 then
	self:EmitSound("payday2/voices/police/bulldozer/visorbreak/bulldozer-92.mp3")
	end
	self:EmitSound("physics/glass/glass_sheet_break2.wav")
	self.VisorGone = true
	self:SetBodygroup(2,1)
	self:VJ_ACT_PLAYACTIVITY("vjseq_flinchhead", false, false, false, 0, {vTbl_SequenceInterruptible=false})
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
		dmginfo:ScaleDamage(0.5)
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/