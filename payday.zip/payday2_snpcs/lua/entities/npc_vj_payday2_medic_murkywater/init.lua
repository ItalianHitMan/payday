AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/humangrunt/payday2/murkywater/murkywater_medicg.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 150
ENT.HullType = HULL_HUMAN
ENT.HasHealthRegeneration = true -- Can the SNPC regenerate its health?
ENT.HealthRegenerationAmount = 6 -- How much should the health increase after every delay?
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.Medic_HealthAmount = 150 -- How health does it give?
ENT.SightDistance = 10000000 -- How far it can see
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.Medic_SpawnPropOnHealModel = "models/payday2/equipments/first_aid_kit.mdl"
ENT.Medic_SpawnPropOnHeal = false -- Should it spawn a prop, such as small health vial at a attachment when healing an ally?
ENT.Medic_CheckDistance = 10000 -- How far does it check for allies that are hurt? | World units
ENT.Medic_HealDistance = 150 -- How close does it have to be until it stops moving and heals its ally?
ENT.Medic_NextHealTime1 = 5 -- How much time until it can give health to an ally again | First number in the math.random
ENT.Medic_NextHealTime2 = 5 -- How much time until it can give health to an ally again | Second number in the math.random
ENT.Medic_TimeUntilHeal = 0 -- Time until the ally receives health | Set to false to let the base decide the time
ENT.HasGrenadeAttack = false -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "obj_vj_grenade"
ENT.AnimTbl_GrenadeAttack = {ACT_RANGE_ATTACK_THROW} -- Grenade Attack Animations
ENT.GrenadeAttackAttachment = "anim_attachment_RH" -- The attachment that the grenade will spawn at, set to false to use a custom position instead
ENT.AnimTbl_MeleeAttack = {"vjseq_MeleeAttack01"} -- Melee Attack Animations
ENT.AnimTbl_Medic_GiveHealth = {"ThrowItem"} -- Animations is plays when giving health to an ally
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = false -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 1 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/combine_soldier/gear1.wav","npc/combine_soldier/gear2.wav","npc/combine_soldier/gear3.wav","npc/combine_soldier/gear4.wav","npc/combine_soldier/gear5.wav","npc/combine_soldier/gear6.wav"}
ENT.SoundTbl_Alert = {"payday2/voices/police/medic/enemyfound/101358235.english.mp3","payday2/voices/police/medic/enemyfound/116011411.english.mp3","payday2/voices/police/medic/enemyfound/152099561.english.mp3","payday2/voices/police/medic/enemyfound/199609595.english.mp3","payday2/voices/police/medic/enemyfound/201151819.english.mp3"}
ENT.SoundTbl_Pain = {"payday2/voices/police/medic/death/448105967.english.mp3"}
ENT.SoundTbl_MedicAfterHeal = {"vjpayday2police/medic/heal1.wav","vjpayday2police/medic/heal2.wav","vjpayday2police/medic/heal3.wav","vjpayday2police/medic/heal4.wav","vjpayday2police/medic/heal5.wav","vjpayday2police/medic/heal6.wav","vjpayday2police/medic/heal7.wav","vjpayday2police/medic/heal8.wav","vjpayday2police/medic/heal9.wav","vjpayday2police/medic/heal10.wav","vjpayday2police/medic/heal11.wav","vjpayday2police/medic/heal12.wav","vjpayday2police/medic/heal13.wav","vjpayday2police/medic/heal14.wav","vjpayday2police/medic/heal15.wav","vjpayday2police/medic/heal16.wav","vjpayday2police/medic/heal17.wav","vjpayday2police/medic/heal18.wav","vjpayday2police/medic/heal19.wav","vjpayday2police/medic/heal20.wav","vjpayday2police/medic/heal21.wav","vjpayday2police/medic/heal22.wav","vjpayday2police/medic/heal23.wav","vjpayday2police/medic/heal24.wav","vjpayday2police/medic/heal25.wav","vjpayday2police/medic/heal26.wav","vjpayday2police/medic/heal27.wav","vjpayday2police/medic/heal28.wav","vjpayday2police/medic/heal29.wav","vjpayday2police/medic/heal30.wav","vjpayday2police/medic/heal31.wav","vjpayday2police/medic/heal32.wav","vjpayday2police/medic/heal33.wav","vjpayday2police/medic/heal34.wav","vjpayday2police/medic/heal35.wav","vjpayday2police/medic/heal36.wav","vjpayday2police/medic/heal37.wav","vjpayday2police/medic/heal38.wav","vjpayday2police/medic/heal39.wav","vjpayday2police/medic/heal40.wav","vjpayday2police/medic/heal41.wav","vjpayday2police/medic/heal42.wav","vjpayday2police/medic/heal43.wav","vjpayday2police/medic/heal44.wav","vjpayday2police/medic/heal45.wav","vjpayday2police/medic/heal46.wav","vjpayday2police/medic/heal47.wav","vjpayday2police/medic/heal48.wav","vjpayday2police/medic/heal49.wav","vjpayday2police/medic/heal50.wav","vjpayday2police/medic/heal51.wav","vjpayday2police/medic/heal52.wav","vjpayday2police/medic/heal53.wav","vjpayday2police/medic/heal54.wav","vjpayday2police/medic/heal55.wav","vjpayday2police/medic/heal56.wav","vjpayday2police/medic/heal57.wav","vjpayday2police/medic/heal58.wav","vjpayday2police/medic/heal59.wav","vjpayday2police/medic/heal60.wav","vjpayday2police/medic/heal61.wav","vjpayday2police/medic/heal62.wav","vjpayday2police/medic/heal63.wav","vjpayday2police/medic/heal64.wav","vjpayday2police/medic/heal65.wav","vjpayday2police/medic/heal66.wav","vjpayday2police/medic/heal67.wav","vjpayday2police/medic/heal68.wav","vjpayday2police/medic/heal69.wav","vjpayday2police/medic/heal70.wav"}
ENT.SoundTbl_Death = {"payday2/voices/police/medic/death/203447196.english.mp3","payday2/voices/police/medic/death/228405582.english.mp3","payday2/voices/police/medic/death/260133290.english.mp3"}

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.Helmet2 = false
ENT.Helmet1 = false
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self.IsMedicSNPC = true
		local rand1 = math.random(1,5)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/police/medic/spawn/138990211.english.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/police/medic/spawn/17753294.english.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/police/medic/spawn/21437769.english.mp3")
	end
		if rand1 == 4 then
	self:EmitSound("payday2/voices/police/medic/spawn/35407843.english.mp3")
	end
		if rand1 == 5 then
	self:EmitSound("payday2/voices/police/medic/spawn/53544332.english.mp3")
	end
	self.Helmet1 = true
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink() 
	self:DoMedicCode()
	self:DoMedicCode()
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_CHEST then
		dmginfo:ScaleDamage(0.7)
	end
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(2)
	end
	if hitgroup == HITGROUP_HEAD && self.Helmet1 == true then
local effectdata = EffectData()
effectdata:SetOrigin(dmginfo:GetDamagePosition())
 util.Effect( "StunstickImpact", effectdata )  
  VJ_EmitSound(self,"n_ricochet_"..math.random(1,2)..".wav",90,100)
	dmginfo:ScaleDamage(0.3)
	self:SetBodygroup(2,1)
	self.hel1 = ents.Create("prop_physics")
	self.hel1:SetModel("models/payday2/helmets/medic.mdl")
	self.hel1:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.hel1:SetMaterial("models/humangrunt/murkywater/medic/material_head_df")
	self.hel1:SetPos(self:GetPos() +self:GetUp()*68 +self:GetRight()*0.1 +self:GetForward()*1)
	self.hel1:SetAngles(self:GetAngles())
	self.hel1:Spawn()
	self.hel1:Activate()
	self.Helmet1 = false
	end
	if hitgroup == HITGROUP_HEAD && self.Helmet2 == true then
	self:SetBodygroup(1,2)
	self.hel2 = ents.Create("prop_physics")
	self.hel2:SetModel("models/payday2/helmets/blue_swat.mdl")
	self.hel2:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.hel2:SetPos(self:GetPos() +self:GetUp()*68 +self:GetRight()*0.1 +self:GetForward()*1)
	self.hel2:SetAngles(self:GetAngles())
	self.hel2:SetBodygroup(0,1)
	self.hel2:Spawn()
	self.hel2:Activate()
	self.Helmet2 = false
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/