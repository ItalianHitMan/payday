AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2017 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vjpayday2police/cloaker.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = GetConVarNumber("vj_pd2cloaker_h")
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.MeleeAttackDamage = GetConVarNumber("vj_pd2cloaker_d")
ENT.FlinchChance = 120
ENT.DistanceToRunFromEnemy = 0

--cloaker
ENT.NextMeleeAttackTime = 3 -- How much time until it can use a melee attack? -- How much time until it can use any attack again? | Counted in Seconds
ENT.SoundTbl_MeleeAttackExtra = {"vjpayday2police/cloaker/hitsound1.wav","vjpayday2police/cloaker/hitsound2.wav"}
ENT.SoundTbl_BeforeMeleeAttack = {"vjpayday2police/cloaker/holyshi.wav"}
ENT.SoundTbl_MeleeAttack = {"vjpayday2police/cloaker/hit1.wav","vjpayday2police/cloaker/hit2.wav","vjpayday2police/cloaker/hit3.wav","vjpayday2police/cloaker/hit4.wav","vjpayday2police/cloaker/hit5.wav","vjpayday2police/cloaker/hit6.wav","vjpayday2police/cloaker/hit7.wav","vjpayday2police/cloaker/hit8.wav","vjpayday2police/cloaker/hit9.wav","vjpayday2police/cloaker/hit10.wav","vjpayday2police/cloaker/hit11.wav","vjpayday2police/cloaker/hit12.wav","vjpayday2police/cloaker/hit13.wav","vjpayday2police/cloaker/hit14.wav","vjpayday2police/cloaker/hit15.wav","vjpayday2police/cloaker/hit16.wav","vjpayday2police/cloaker/hit17.wav","vjpayday2police/cloaker/hit18.wav","vjpayday2police/cloaker/hit19.wav","vjpayday2police/cloaker/hit20.wav","vjpayday2police/cloaker/hit21.wav","vjpayday2police/cloaker/hit22.wav","vjpayday2police/cloaker/hit23.wav","vjpayday2police/cloaker/hit24.wav","vjpayday2police/cloaker/hit25.wav","vjpayday2police/cloaker/hit26.wav","vjpayday2police/cloaker/hit27.wav","vjpayday2police/cloaker/hit28.wav","vjpayday2police/cloaker/hit29.wav","vjpayday2police/cloaker/hit30.wav","vjpayday2police/cloaker/hit31.wav","vjpayday2police/cloaker/hit32.wav","vjpayday2police/cloaker/hit33.wav","vjpayday2police/cloaker/hit34.wav","vjpayday2police/cloaker/hit35.wav","vjpayday2police/cloaker/hit36.wav","vjpayday2police/cloaker/hit37.wav","vjpayday2police/cloaker/hit38.wav","vjpayday2police/cloaker/hit39.wav"}
ENT.SoundTbl_Death = {"vjpayday2police/cloaker/die1.wav","vjpayday2police/cloaker/die2.wav","vjpayday2police/cloaker/die3.wav","vjpayday2police/cloaker/die4.wav","vjpayday2police/cloaker/die5.wav","vjpayday2police/cloaker/die7.wav","vjpayday2police/cloaker/die8.wav","vjpayday2police/cloaker/die9.wav","vjpayday2police/cloaker/die10.wav","vjpayday2police/cloaker/die11.wav","vjpayday2police/cloaker/die12.wav","vjpayday2police/cloaker/die13.wav","vjpayday2police/cloaker/die14.wav"}
ENT.DeathSoundChance = 1

function ENT:CustomOnPreInitialize()
if GetConVarNumber("vj_pd2_disablecrouchidle") == 0 then 
if math.random(0,2) == 2 then
self.AnimTbl_IdleStand = {ACT_CROUCHIDLE}
end
end
end

function ENT:CustomOnInitialize()
if GetConVarNumber("vj_pd2_copfriendly") == 1 then
self.VJ_NPC_Class = {"CLASS_UNITED_STATES_FRIENDLY"}
self.PlayerFriendly = true
self.FriendsWithAllPlayerAllies = true
end
end

function ENT:CustomOnThink()
	if self.NearestPointToEnemyDistance > 20 && self.NearestPointToEnemyDistance < 270 then
		self.MeleeAttackDistance = 270
		self.MeleeAttackDamageDistance = 115
		self.AnimTbl_MeleeAttack = {"Sprint_All"}
		self.TimeUntilMeleeAttackDamage = 1
		self.NextMeleeAttackTime = 3
		self.HasMeleeAttackKnockBack = true
		self.MeleeAttackKnockBack_Forward1 = 270
		self.MeleeAttackKnockBack_Forward2 = 290
		self.MeleeAttackKnockBack_Up1 = 300
		self.MeleeAttackKnockBack_Up2 = 310
		self.MeleeAttack_NoProps = true
		self:SetSkin(1)
	end
	if self.NearestPointToEnemyDistance > 210 then
			self:SetSkin(0)
end
end

/*-----------------------------------------------
	*** Copyright (c) 2012-2017 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/