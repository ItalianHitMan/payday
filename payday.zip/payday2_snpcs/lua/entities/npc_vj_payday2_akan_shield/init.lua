AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vjpayday2police/akan_shield.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 135
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_RUSSIAN"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.HasMeleeAttack = false
ENT.MeleeAttackDamage = 10
ENT.SightDistance = 10000000 -- How far it can see
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.Medic_SpawnPropOnHealModel = "models/weapons/w_eq_medkit.mdl"
ENT.CanCrouchOnWeaponAttack = false -- Can it crouch while shooting?
ENT.HasGrenadeAttack = false -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "proj_drg_flashbang"
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 1 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
ENT.CanCrouchOnWeaponAttack = false -- Can it crouch while shooting?
ENT.ConstantlyFaceEnemy = true -- Should it face the enemy constantly?
ENT.AnimTbl_TakingCover = {"vjseq_CombatIdle1"} -- The animation it plays when hiding in a covered position
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/police/medic/onhelp/123648013.english.mp3","payday2/voices/police/medic/onhelp/142637101.english.mp3","payday2/voices/police/medic/onhelp/287516577.english.mp3","payday2/voices/police/medic/onhelp/33768141.english.mp3"}
ENT.SoundTbl_Alert = {"vjpayday2police/russians/contact1.wav","vjpayday2police/russians/contact2.wav","vjpayday2police/russians/contact3.wav","vjpayday2police/russians/contact4.wav","vjpayday2police/russians/contact5.wav","vjpayday2police/russians/contact6.wav","vjpayday2police/russians/contact7.wav","vjpayday2police/russians/contact8.wav","vjpayday2police/russians/contact9.wav","vjpayday2police/russians/contact10.wav","vjpayday2police/russians/contact11.wav","vjpayday2police/russians/contact12.wav","vjpayday2police/russians/contact13.wav","vjpayday2police/russians/contact14.wav"}
ENT.SoundTbl_CallForHelp = {"vjpayday2police/russians/callhelp1.wav","vjpayday2police/russians/callhelp2.wav","vjpayday2police/russians/callhelp3.wav","vjpayday2police/russians/callhelp4.wav","vjpayday2police/russians/callhelp5.wav","vjpayday2police/russians/callhelp6.wav"}
ENT.SoundTbl_WeaponReload = {"vjpayday2police/russians/coverme1.wav","vjpayday2police/russians/coverme2.wav","vjpayday2police/russians/coverme3.wav","vjpayday2police/russians/coverme4.wav","vjpayday2police/russians/coverme5.wav","vjpayday2police/russians/coverme6.wav","vjpayday2police/russians/coverme7.wav","vjpayday2police/russians/coverme8.wav"}
ENT.SoundTbl_GrenadeAttack = {"vjpayday2police/russians/taunt1.wav","vjpayday2police/russians/taunt2.wav","vjpayday2police/russians/taunt3.wav"}
ENT.SoundTbl_Pain = {"vjpayday2police/russians/pain1.wav","vjpayday2police/russians/pain2.wav","vjpayday2police/russians/pain3.wav","vjpayday2police/russians/pain4.wav","vjpayday2police/russians/pain5.wav"}
ENT.SoundTbl_Death = {"vjpayday2police/russians/die1.wav","vjpayday2police/russians/die2.wav","vjpayday2police/russians/die3.wav","vjpayday2police/russians/die4.wav","vjpayday2police/russians/die5.wav","vjpayday2police/russians/die6.wav","vjpayday2police/russians/die7.wav","vjpayday2police/russians/die8.wav"}

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.Helmet2 = false
ENT.Helmet1 = false
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
		self.AnimTbl_WeaponAttack = {self:GetSequenceActivity(self:LookupSequence("shootSMG1s"))}
		self.AnimTbl_WeaponReload = {self:GetSequenceActivity(self:LookupSequence("CombatIdle1"))}
		self.AnimTbl_WeaponReloadBehindCover = {self:GetSequenceActivity(self:LookupSequence("CombatIdle1"))}
		self.AnimTbl_Walk = {ACT_WALK_AIM}
		self.AnimTbl_Run = {ACT_RUN_AIM}
end
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
		local rand2 = math.random(1,2)
		if rand2 == 1 then
	self:SetSkin(1)
	end
		if rand2 == 2 then
	self:SetSkin(3)
	end

local boneid = self:LookupBone( "ValveBiped.Bip01_L_Hand" )
local matrix = self:GetBoneMatrix( boneid )

self.m = ents.Create( "prop_physics" )
self.m:SetModel("models/vjpayday2police/weapons/akan_shield.mdl")
self.m:SetPos(self:LocalToWorld(Vector(-7,4,-16)))
self.m:SetAngles(self:GetAngles()+Angle(0,90,3))
self.m:SetOwner( self )
self.m:SetParent(self)
self.m:Spawn()
self.m:Activate()
self.m:FollowBone( self, boneid )
self.m:EmitSound("vjpayday2police/shield/bangbangbang.wav")
self.m:SetCollisionGroup( COLLISION_GROUP_WEAPON )
		local rand1 = math.random(1,5)
		if rand1 == 1 then
	self.Helmet1 = true
	self:SetBodygroup(1,0)
	end
		if rand1 == 2 then
	self.Helmet2 = true
	self:SetBodygroup(1,1)
	end
		if rand1 == 3 then
	self.Helmet3 = true
	self:SetBodygroup(1,2)
	end
		if rand1 == 4 then
	self.Helmet4 = true
	self:SetBodygroup(1,4)
	end
		if rand1 == 5 then
	self.Helmet5 = true
	self:SetBodygroup(1,5)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_CHEST then
		dmginfo:ScaleDamage(0.7)
	end
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(2)
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnDeath_AfterCorpseSpawned(dmginfo,hitgroup,GetCorpse)
	self.riot = ents.Create("prop_physics")
	self.riot:SetModel("models/vjpayday2police/weapons/akan_shield.mdl")
	self.riot:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.riot:SetPos(self:GetPos() +self:GetUp()*47 +self:GetForward()*24)
	self.riot:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.riot:Spawn()
	self.riot:Activate()
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/