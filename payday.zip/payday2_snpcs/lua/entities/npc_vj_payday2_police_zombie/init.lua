AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/payday2/halloween_units/halloween_cop_1_rebel.mdl","models/payday2/halloween_units/halloween_cop_2_rebel.mdl","models/payday2/halloween_units/halloween_cop_2_rebel.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 40
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.SightDistance = 10000000 -- How far it can see
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.AnimTbl_MeleeAttack = {ACT_MELEE_ATTACK_SWING} -- Melee Attack Animations
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 0 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== File Path Variables ====== --
	-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/police/medic/onhelp/123648013.english.mp3","payday2/voices/police/medic/onhelp/142637101.english.mp3","payday2/voices/police/medic/onhelp/287516577.english.mp3","payday2/voices/police/medic/onhelp/33768141.english.mp3"}
ENT.SoundTbl_Alert = {"payday2/voices/police/regular/enemyfound/10680530.1.mp3","payday2/voices/police/regular/enemyfound/173638177.1.mp3","payday2/voices/police/regular/enemyfound/22673528.1.mp3","payday2/voices/police/regular/enemyfound/3529354.1.mp3","payday2/voices/police/regular/enemyfound/468709881.1.mp3","payday2/voices/police/regular/enemyfound/52090260.1.mp3","payday2/voices/police/regular/enemyfound/630502375.1.mp3","payday2/voices/police/regular/enemyfound/642233273.1.mp3","payday2/voices/police/regular/enemyfound/646540601.1.mp3","payday2/voices/police/regular/enemyfound/93064458.1.mp3"}
ENT.SoundTbl_CallForHelp = {"payday2/voices/police/regular/cover/663167685.1.mp3","payday2/voices/police/regular/cover/917901918.1.mp3","payday2/voices/police/regular/cover/654751639.1.mp3","payday2/voices/police/regular/cover/118896249.1.mp3"}
ENT.SoundTbl_WeaponReload = {"payday2/voices/police/regular/cover/1038869175.1.mp3","payday2/voices/police/regular/cover/126281640.1.mp3","payday2/voices/police/regular/cover/131075466.1.mp3","payday2/voices/police/regular/cover/31879248.1.mp3","payday2/voices/police/regular/cover/798237364.1.mp3","payday2/voices/police/regular/cover/8093501.1.mp3"}
ENT.SoundTbl_GrenadeAttack = {"payday2/voices/police/regular/flashbang/117766465.1.mp3","payday2/voices/police/regular/flashbang/119615441.1.mp3","payday2/voices/police/regular/flashbang/459426581.1.mp3","payday2/voices/police/regular/flashbang/729632569.1.mp3","payday2/voices/police/regular/flashbang/800057952.1.mp3","payday2/voices/police/regular/flashbang/884743354.1.mp3","payday2/voices/police/regular/flashbang/899408221.1.mp3","payday2/voices/police/regular/flashbang/96940088.1.mp3","payday2/voices/police/regular/flashbang/998288951.1.mp3"}
ENT.SoundTbl_Pain = {"payday2/voices/police/regular/death/880674776.1.mp3","payday2/voices/police/regular/death/87460061.1.mp3"}
ENT.SoundTbl_Death = {"payday2/voices/police/regular/death/1003011234.1.mp3","payday2/voices/police/regular/death/15237935.1.mp3","payday2/voices/police/regular/death/18281706.1.mp3","payday2/voices/police/regular/death/38050603.1.mp3","payday2/voices/police/regular/death/45543700.1.mp3","payday2/voices/police/regular/death/66572380.1.mp3","payday2/voices/police/regular/death/685485541.1.mp3"}

ENT.GeneralSoundPitch1 = 70
ENT.GeneralSoundPitch2 = 70

/*
-- Number sounds have not been included!

"npc/metropolice/vo/amputate.wav"
"npc/metropolice/vo/anticitizen.wav"
"npc/metropolice/vo/apply.wav"
"npc/metropolice/vo/block.wav"
"npc/metropolice/vo/blockisholdingcohesive.wav"
"npc/metropolice/vo/canal.wav"
"npc/metropolice/vo/canalblock.wav"
"npc/metropolice/vo/catchthatbliponstabilization.wav"
"npc/metropolice/vo/cauterize.wav"
"npc/metropolice/vo/checkformiscount.wav"
"npc/metropolice/vo/citizen.wav"
"npc/metropolice/vo/citizensummoned.wav"
"npc/metropolice/vo/classifyasdbthisblockready.wav"
"npc/metropolice/vo/clearno647no10-107.wav"
"npc/metropolice/vo/code100.wav"
"npc/metropolice/vo/confirmpriority1sighted.wav"
"npc/metropolice/vo/contactwithpriority2.wav"
"npc/metropolice/vo/controlsection.wav"
"npc/metropolice/vo/defender.wav"
"npc/metropolice/vo/designatesuspectas.wav"
"npc/metropolice/vo/document.wav"
"npc/metropolice/vo/dontmove.wav"
"npc/metropolice/vo/examine.wav"
"npc/metropolice/vo/expired.wav"
"npc/metropolice/vo/externaljurisdiction.wav"
"npc/metropolice/vo/finalverdictadministered.wav"
"npc/metropolice/vo/finalwarning.wav"
"npc/metropolice/vo/firstwarningmove.wav"
"npc/metropolice/vo/hero.wav"
"npc/metropolice/vo/hesgone148.wav"
"npc/metropolice/vo/hidinglastseenatrange.wav"
"npc/metropolice/vo/holdit.wav"
"npc/metropolice/vo/holditrightthere.wav"
"npc/metropolice/vo/industrialzone.wav"
"npc/metropolice/vo/infection.wav"
"npc/metropolice/vo/infestedzone.wav"
"npc/metropolice/vo/inject.wav"
"npc/metropolice/vo/innoculate.wav"
"npc/metropolice/vo/intercede.wav"
"npc/metropolice/vo/isaidmovealong.wav"
"npc/metropolice/vo/isolate.wav"
"npc/metropolice/vo/isreadytogo.wav"
"npc/metropolice/vo/jury.wav"
"npc/metropolice/vo/king.wav"
"npc/metropolice/vo/line.wav"
"npc/metropolice/vo/location.wav"
"npc/metropolice/vo/lock.wav"
"npc/metropolice/vo/lookingfortrouble.wav"
"npc/metropolice/vo/loyaltycheckfailure.wav"
"npc/metropolice/vo/matchonapblikeness.wav"
"npc/metropolice/vo/meters.wav"
"npc/metropolice/vo/minorhitscontinuing.wav"
"npc/metropolice/vo/move.wav"
"npc/metropolice/vo/movealong.wav"
"npc/metropolice/vo/movealong3.wav"
"npc/metropolice/vo/moveit2.wav"
"npc/metropolice/vo/nowgetoutofhere.wav"
"npc/metropolice/vo/outbreak.wav"
"npc/metropolice/vo/outlandzone.wav"
"npc/metropolice/vo/pickupthecan1.wav" - 3
"npc/metropolice/vo/preserve.wav"
"npc/metropolice/vo/pressure.wav"
"npc/metropolice/vo/productionblock.wav"
"npc/metropolice/vo/prosecute.wav"
"npc/metropolice/vo/ptgoagain.wav"
"npc/metropolice/vo/putitinthetrash1.wav" - 2
"npc/metropolice/vo/quick.wav"
"npc/metropolice/vo/readytoprosecutefinalwarning.wav"
"npc/metropolice/vo/repurposedarea.wav"
"npc/metropolice/vo/residentialblock.wav"
"npc/metropolice/vo/restrict.wav"
"npc/metropolice/vo/restrictedblock.wav"
"npc/metropolice/vo/roller.wav"
"npc/metropolice/vo/search.wav"
"npc/metropolice/vo/secondwarning.wav"
"npc/metropolice/vo/sector.wav"
"npc/metropolice/vo/sentencedelivered.wav"
"npc/metropolice/vo/serve.wav"
"npc/metropolice/vo/stabilizationjurisdiction.wav"
"npc/metropolice/vo/stationblock.wav"
"npc/metropolice/vo/sterilize.wav"
"npc/metropolice/vo/stick.wav"
"npc/metropolice/vo/stillgetting647e.wav"
"npc/metropolice/vo/stormsystem.wav"
"npc/metropolice/vo/tagonenecrotic.wav"
"npc/metropolice/vo/tagoneparasitic.wav"
"npc/metropolice/vo/tap.wav"
"npc/metropolice/vo/ten91dcountis.wav"
"npc/metropolice/vo/terminalrestrictionzone.wav"
"npc/metropolice/vo/therehegoeshesat.wav"
"npc/metropolice/vo/thisisyoursecondwarning.wav"
"npc/metropolice/vo/transitblock.wav"
"npc/metropolice/vo/union.wav"
"npc/metropolice/vo/unitis10-65.wav"
"npc/metropolice/vo/unlawfulentry603.wav"
"npc/metropolice/vo/upi.wav"
"npc/metropolice/vo/utlthatsuspect.wav"
"npc/metropolice/vo/vacatecitizen.wav"
"npc/metropolice/vo/vice.wav"
"npc/metropolice/vo/victor.wav"
"npc/metropolice/vo/wasteriver.wav"
"npc/metropolice/vo/wegotadbherecancel10-102.wav"
"npc/metropolice/vo/workforceintake.wav"
"npc/metropolice/vo/xray.wav"
"npc/metropolice/vo/yellow.wav"
"npc/metropolice/vo/youknockeditover.wav"
"npc/metropolice/vo/youwantamalcomplianceverdict.wav"
"npc/metropolice/vo/zone.wav"

-- Manhack deploy
"npc/metropolice/vo/visceratordeployed.wav"
"npc/metropolice/vo/visceratorisoc.wav"
"npc/metropolice/vo/visceratorisoffgrid.wav"

"npc/metropolice/vo/off1.wav" - 4
"npc/metropolice/vo/on1.wav" - 2
*/
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
	if IsValid(self:GetActiveWeapon()) && self:GetActiveWeapon().HoldType == "smg" then
	self.AnimTbl_MeleeAttack = {"vjseq_MeleeAttack01"}
	end
end
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetBodygroup(1,math.random(0,1))
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(2)
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/