AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.StartHealth = 5
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.HasMeleeAttack = false -- Should the SNPC have a melee attack?
ENT.AnimTbl_MeleeAttack = {ACT_MELEE_ATTACK_SWING} -- Melee Attack Animations
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 0 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
ENT.Behavior = VJ_BEHAVIOR_PASSIVE
ENT.Weapon_NoSpawnMenu = true -- If set to true, the NPC weapon setting in the spawnmenu will not be applied for this SNPC
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== File Path Variables ====== --
	-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}

/*
-- Number sounds have not been included!

"npc/metropolice/vo/amputate.wav"
"npc/metropolice/vo/anticitizen.wav"
"npc/metropolice/vo/apply.wav"
"npc/metropolice/vo/block.wav"
"npc/metropolice/vo/blockisholdingcohesive.wav"
"npc/metropolice/vo/canal.wav"
"npc/metropolice/vo/canalblock.wav"
"npc/metropolice/vo/catchthatbliponstabilization.wav"
"npc/metropolice/vo/cauterize.wav"
"npc/metropolice/vo/checkformiscount.wav"
"npc/metropolice/vo/citizen.wav"
"npc/metropolice/vo/citizensummoned.wav"
"npc/metropolice/vo/classifyasdbthisblockready.wav"
"npc/metropolice/vo/clearno647no10-107.wav"
"npc/metropolice/vo/code100.wav"
"npc/metropolice/vo/confirmpriority1sighted.wav"
"npc/metropolice/vo/contactwithpriority2.wav"
"npc/metropolice/vo/controlsection.wav"
"npc/metropolice/vo/defender.wav"
"npc/metropolice/vo/designatesuspectas.wav"
"npc/metropolice/vo/document.wav"
"npc/metropolice/vo/dontmove.wav"
"npc/metropolice/vo/examine.wav"
"npc/metropolice/vo/expired.wav"
"npc/metropolice/vo/externaljurisdiction.wav"
"npc/metropolice/vo/finalverdictadministered.wav"
"npc/metropolice/vo/finalwarning.wav"
"npc/metropolice/vo/firstwarningmove.wav"
"npc/metropolice/vo/hero.wav"
"npc/metropolice/vo/hesgone148.wav"
"npc/metropolice/vo/hidinglastseenatrange.wav"
"npc/metropolice/vo/holdit.wav"
"npc/metropolice/vo/holditrightthere.wav"
"npc/metropolice/vo/industrialzone.wav"
"npc/metropolice/vo/infection.wav"
"npc/metropolice/vo/infestedzone.wav"
"npc/metropolice/vo/inject.wav"
"npc/metropolice/vo/innoculate.wav"
"npc/metropolice/vo/intercede.wav"
"npc/metropolice/vo/isaidmovealong.wav"
"npc/metropolice/vo/isolate.wav"
"npc/metropolice/vo/isreadytogo.wav"
"npc/metropolice/vo/jury.wav"
"npc/metropolice/vo/king.wav"
"npc/metropolice/vo/line.wav"
"npc/metropolice/vo/location.wav"
"npc/metropolice/vo/lock.wav"
"npc/metropolice/vo/lookingfortrouble.wav"
"npc/metropolice/vo/loyaltycheckfailure.wav"
"npc/metropolice/vo/matchonapblikeness.wav"
"npc/metropolice/vo/meters.wav"
"npc/metropolice/vo/minorhitscontinuing.wav"
"npc/metropolice/vo/move.wav"
"npc/metropolice/vo/movealong.wav"
"npc/metropolice/vo/movealong3.wav"
"npc/metropolice/vo/moveit2.wav"
"npc/metropolice/vo/nowgetoutofhere.wav"
"npc/metropolice/vo/outbreak.wav"
"npc/metropolice/vo/outlandzone.wav"
"npc/metropolice/vo/pickupthecan1.wav" - 3
"npc/metropolice/vo/preserve.wav"
"npc/metropolice/vo/pressure.wav"
"npc/metropolice/vo/productionblock.wav"
"npc/metropolice/vo/prosecute.wav"
"npc/metropolice/vo/ptgoagain.wav"
"npc/metropolice/vo/putitinthetrash1.wav" - 2
"npc/metropolice/vo/quick.wav"
"npc/metropolice/vo/readytoprosecutefinalwarning.wav"
"npc/metropolice/vo/repurposedarea.wav"
"npc/metropolice/vo/residentialblock.wav"
"npc/metropolice/vo/restrict.wav"
"npc/metropolice/vo/restrictedblock.wav"
"npc/metropolice/vo/roller.wav"
"npc/metropolice/vo/search.wav"
"npc/metropolice/vo/secondwarning.wav"
"npc/metropolice/vo/sector.wav"
"npc/metropolice/vo/sentencedelivered.wav"
"npc/metropolice/vo/serve.wav"
"npc/metropolice/vo/stabilizationjurisdiction.wav"
"npc/metropolice/vo/stationblock.wav"
"npc/metropolice/vo/sterilize.wav"
"npc/metropolice/vo/stick.wav"
"npc/metropolice/vo/stillgetting647e.wav"
"npc/metropolice/vo/stormsystem.wav"
"npc/metropolice/vo/tagonenecrotic.wav"
"npc/metropolice/vo/tagoneparasitic.wav"
"npc/metropolice/vo/tap.wav"
"npc/metropolice/vo/ten91dcountis.wav"
"npc/metropolice/vo/terminalrestrictionzone.wav"
"npc/metropolice/vo/therehegoeshesat.wav"
"npc/metropolice/vo/thisisyoursecondwarning.wav"
"npc/metropolice/vo/transitblock.wav"
"npc/metropolice/vo/union.wav"
"npc/metropolice/vo/unitis10-65.wav"
"npc/metropolice/vo/unlawfulentry603.wav"
"npc/metropolice/vo/upi.wav"
"npc/metropolice/vo/utlthatsuspect.wav"
"npc/metropolice/vo/vacatecitizen.wav"
"npc/metropolice/vo/vice.wav"
"npc/metropolice/vo/victor.wav"
"npc/metropolice/vo/wasteriver.wav"
"npc/metropolice/vo/wegotadbherecancel10-102.wav"
"npc/metropolice/vo/workforceintake.wav"
"npc/metropolice/vo/xray.wav"
"npc/metropolice/vo/yellow.wav"
"npc/metropolice/vo/youknockeditover.wav"
"npc/metropolice/vo/youwantamalcomplianceverdict.wav"
"npc/metropolice/vo/zone.wav"

-- Manhack deploy
"npc/metropolice/vo/visceratordeployed.wav"
"npc/metropolice/vo/visceratorisoc.wav"
"npc/metropolice/vo/visceratorisoffgrid.wav"

"npc/metropolice/vo/off1.wav" - 4
"npc/metropolice/vo/on1.wav" - 2
*/
-- Custom
ENT.Human_Gender = 0 -- 0 = Male | 1 = Female
ENT.Human_SdFolder = "male01"
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPreInitialize()
	if math.random(1,2) == 1 then
		self.Human_Gender = 0
		if math.random(1,5) == 1 then
			self.Model = {"models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_npc.mdl","models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_npc.mdl"}
	else
			self.Model = {"models/smalls_civilians/pack2/male/flannel/male_01_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_02_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_03_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_04_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_05_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_06_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_07_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_08_flannel_npc.mdl","models/smalls_civilians/pack2/male/flannel/male_09_flannel_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_01_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_02_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_03_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_04_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_05_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_06_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_07_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_08_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_jeans/male_09_hoodiejeans_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_01_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_02_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_03_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_04_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_05_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_06_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_07_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_08_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/hoodie_sweatpants/male_09_hoodiesweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_01_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_02_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_03_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_04_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_05_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_06_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_07_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_08_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_09_jacketvneck_sweatpants_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_npc.mdl","models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_npc.mdl"}
		end
	else
		self.Human_Gender = 1
		if math.random(1,5) == 1 then
			self.Model = {"models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_01_hoodiepulloverjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_02_hoodiepulloverjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_03_hoodiepulloverjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_04_hoodiepulloverjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_06_hoodiepulloverjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_07_hoodiepulloverjeans_npc.mdl"}
	else
			self.Model = {"models/smalls_civilians/pack2/female/hoodiepulloversweats/female_01_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloversweats/female_02_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloversweats/female_03_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloversweats/female_04_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloversweats/female_06_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedjeans/female_01_hoodiezippedjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedjeans/female_02_hoodiezippedjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedjeans/female_03_hoodiezippedjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedjeans/female_04_hoodiezippedjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedjeans/female_06_hoodiezippedjeans_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedsweats/female_03_hoodiezippedsweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedsweats/female_04_hoodiezippedsweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedsweats/female_06_hoodiezippedsweats_npc.mdl","models/smalls_civilians/pack2/female/hoodiezippedsweats/female_07_hoodiezippedsweats_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_01_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_02_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_03_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_04_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_06_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkajeans/female_07_parkajeans_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_01_parkasweats_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_02_parkasweats_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_03_parkasweats_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_04_parkasweats_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_06_parkasweats_npc.mdl","models/smalls_civilians/pack2/female/parkasweats/female_07_parkasweats_npc.mdl"}
		end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self.Human_NextPlyReloadSd = CurTime()
	if self.Human_Gender == 1 then
		self:HLR_ApplyFemaleSounds()
		self.Human_SdFolder = "female01"
	else
		self:HLR_ApplyMaleSounds()
		self.Human_SdFolder = "male01"
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_AfterDamage(dmginfo,hitgroup)
	if self:Health() > 0 && math.random(1,2) == 1 then
		if hitgroup == HITGROUP_LEFTARM or hitgroup == HITGROUP_RIGHTARM then
			self:PlaySoundSystem("Pain", {
				"vo/npc/"..self.Human_SdFolder.."/myarm01.wav",
				"vo/npc/"..self.Human_SdFolder.."/myarm02.wav",
			})
		elseif hitgroup == HITGROUP_LEFTLEG or hitgroup == HITGROUP_RIGHTLEG then
			self:PlaySoundSystem("Pain", {
				"vo/npc/"..self.Human_SdFolder.."/myleg01.wav",
				"vo/npc/"..self.Human_SdFolder.."/myleg02.wav",
			})
		elseif hitgroup == HITGROUP_STOMACH then
			self:PlaySoundSystem("Pain", {
				"vo/npc/"..self.Human_SdFolder.."/hitingut01.wav",
				"vo/npc/"..self.Human_SdFolder.."/hitingut02.wav",
				"vo/npc/"..self.Human_SdFolder.."/mygut02.wav",
			})
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------ SOUNDS ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function ENT:HLR_ApplyMaleSounds()
	self.SoundTbl_MedicBeforeHeal = {
		"vo/npc/male01/health01.wav",
		"vo/npc/male01/health02.wav",
		"vo/npc/male01/health03.wav",
		"vo/npc/male01/health04.wav",
		"vo/npc/male01/health05.wav"
	}
	self.SoundTbl_MedicAfterHeal = {}
	self.SoundTbl_MedicReceiveHeal = {}
	self.SoundTbl_Investigate = {
		"vo/npc/male01/startle01.wav",
		"vo/npc/male01/startle02.wav",
		"vo/canals/boxcar_becareful.wav",
		"vo/streetwar/sniper/male01/c17_09_help03.wav",
	}
	self.SoundTbl_LostEnemy = {}
	self.SoundTbl_Alert = {
		"vo/npc/male01/headsup01.wav",
		"vo/npc/male01/headsup02.wav",
		"vo/npc/male01/heretheycome01.wav",
		"vo/npc/male01/incoming02.wav",
		"vo/npc/male01/overhere01.wav",
		"vo/npc/male01/overthere01.wav",
		"vo/npc/male01/overthere02.wav",
		"vo/npc/male01/squad_away02.wav",
		"vo/npc/male01/upthere01.wav",
		"vo/npc/male01/upthere02.wav",
		"vo/canals/male01/stn6_incoming.wav",
	}
	self.SoundTbl_CallForHelp = {
		"vo/npc/male01/help01.wav",
		"vo/coast/bugbait/sandy_help.wav",
		"vo/streetwar/sniper/male01/c17_09_help01.wav",
		"vo/streetwar/sniper/male01/c17_09_help02.wav",
	}
	self.SoundTbl_Suppressing = {}
	self.SoundTbl_WeaponReload = {
		"vo/npc/male01/coverwhilereload01.wav",
		"vo/npc/male01/coverwhilereload02.wav",
		"vo/npc/male01/gottareload01.wav",
	}
	self.SoundTbl_BeforeMeleeAttack = {}
	self.SoundTbl_MeleeAttack = {}
	self.SoundTbl_MeleeAttackExtra = {}
	self.SoundTbl_MeleeAttackMiss = {}
	self.SoundTbl_GrenadeAttack = {}
	self.SoundTbl_OnGrenadeSight = {
		"vo/npc/male01/getdown02.wav",
		"vo/npc/male01/gethellout.wav",
		"vo/npc/male01/runforyourlife01.wav",
		"vo/npc/male01/runforyourlife02.wav",
		"vo/npc/male01/runforyourlife03.wav",
		"vo/npc/male01/strider_run.wav",
		"vo/npc/male01/takecover02.wav",
		"vo/npc/male01/uhoh.wav",
		"vo/npc/male01/watchout.wav",
	}
	self.SoundTbl_OnKilledEnemy = {
		"vo/npc/male01/gotone01.wav",
		"vo/npc/male01/gotone02.wav",
		"vo/npc/male01/nice.wav",
		"vo/npc/male01/ohno.wav",
		"vo/npc/male01/yeah02.wav",
		"vo/coast/odessa/male01/nlo_cheer01.wav",
		"vo/coast/odessa/male01/nlo_cheer02.wav",
		"vo/coast/odessa/male01/nlo_cheer03.wav",
		"vo/coast/odessa/male01/nlo_cheer04.wav",
	}
	self.SoundTbl_AllyDeath = {
		"vo/npc/male01/goodgod.wav",
		"vo/npc/male01/likethat.wav",
		"vo/npc/male01/no01.wav",
		"vo/npc/male01/no02.wav",
		"vo/canals/matt_beglad_b.wav",
		"vo/coast/odessa/male01/nlo_cubdeath01.wav",
		"vo/coast/odessa/male01/nlo_cubdeath02.wav",
	}
	self.SoundTbl_Pain = {
		"vo/npc/male01/imhurt01.wav",
		"vo/npc/male01/imhurt02.wav",
		"vo/npc/male01/ow01.wav",
		"vo/npc/male01/ow02.wav",
		"vo/npc/male01/pain01.wav",
		"vo/npc/male01/pain02.wav",
		"vo/npc/male01/pain03.wav",
		"vo/npc/male01/pain04.wav",
		"vo/npc/male01/pain05.wav",
		"vo/npc/male01/pain06.wav",
	}
	self.SoundTbl_Death = {
		"vo/npc/male01/pain07.wav",
		"vo/npc/male01/pain08.wav",
		"vo/npc/male01/pain09.wav"
	}

	--[[ CUSTOM CODE

	]]--


	--[[ UNUSED

	-- Alert player of danger
	vo/npc/male01/lookoutfm01.wav
	vo/npc/male01/lookoutfm02.wav
	vo/npc/male01/behindyou01.wav
	vo/npc/male01/behindyou02.wav

	-- Player died
	vo/npc/male01/gordead_ans01.wav		1 - 20
	vo/npc/male01/gordead_ques01.wav	1 - 17

	-- Give player ammo
	vo/npc/male01/ammo01.wav	1 - 5

	-- Pick-up weapon
	vo/npc/male01/fantastic01.wav
	vo/npc/male01/fantastic02.wav
	vo/npc/male01/evenodds.wav	-- Also in "Taking out RPG"
	vo/npc/male01/finally.wav
	vo/npc/male01/nice.wav
	vo/npc/male01/oneforme.wav
	vo/npc/male01/thislldonicely01.wav

	-- Vortigaunt Answer and Question
	vo/npc/male01/vanswer02.wav
	vo/npc/male01/vanswer03.wav
	vo/npc/male01/vanswer05.wav
	vo/npc/male01/vanswer06.wav
	vo/npc/male01/vanswer07.wav
	vo/npc/male01/vanswer09.wav
	vo/npc/male01/vanswer10.wav
	vo/npc/male01/vanswer11.wav
	vo/npc/male01/vanswer12.wav
	"vo/npc/male01/vquestion03.wav",
	vo/npc/male01/vquestion05.wav
	vo/npc/male01/vquestion06.wav
	vo/npc/male01/vquestion07.wav

	-- Follow player not moving
	vo/npc/male01/waitingsomebody.wav

	vo/npc/male01/busy02.wav
	
	-- Supplies
	vo/npc/male01/cit_dropper01.wav
	vo/npc/male01/cit_dropper04.wav

	vo/npc/male01/moan01.wav	 1 - 5

	vo/npc/male01/squad_approach01.wav
	vo/npc/male01/squad_away01.wav
	vo/npc/male01/squad_away03.wav
	vo/npc/male01/squad_follow01.wav
	vo/npc/male01/squad_follow02.wav
	vo/npc/male01/squad_follow04.wav
	"vo/npc/male01/squad_greet02.wav",
	vo/npc/male01/squad_reinforce_group01.wav	1 - 4
	vo/npc/male01/squad_reinforce_single01.wav	1 - 4
	
	vo/canals/male01/gunboat_breakcamp.wav
	vo/canals/male01/gunboat_eliright.wav
	vo/canals/male01/gunboat_hurry.wav
	vo/canals/male01/gunboat_justintime.wav
	vo/canals/male01/gunboat_moveon.wav
	vo/canals/male01/gunboat_parkboat.wav
	vo/canals/male01/gunboat_pullout.wav
	vo/canals/male01/stn6_shellingus.wav
	
	]]--
end

function ENT:HLR_ApplyFemaleSounds()
	self.SoundTbl_MedicBeforeHeal = {
		"vo/npc/female01/health01.wav",
		"vo/npc/female01/health02.wav",
		"vo/npc/female01/health03.wav",
		"vo/npc/female01/health04.wav",
		"vo/npc/female01/health05.wav",
	}
	self.SoundTbl_MedicAfterHeal = {}
	self.SoundTbl_MedicReceiveHeal = {}
	self.SoundTbl_Investigate = {
		"vo/npc/female01/startle01.wav",
		"vo/npc/female01/startle02.wav",
	}
	self.SoundTbl_LostEnemy = {}
	self.SoundTbl_Alert = {
		"vo/npc/female01/headsup01.wav",
		"vo/npc/female01/headsup02.wav",
		"vo/npc/female01/heretheycome01.wav",
		"vo/npc/female01/incoming02.wav",
		"vo/npc/female01/overhere01.wav",
		"vo/npc/female01/overthere01.wav",
		"vo/npc/female01/overthere02.wav",
		"vo/npc/female01/squad_away02.wav",
		"vo/npc/female01/upthere01.wav",
		"vo/npc/female01/upthere02.wav",
		"vo/canals/female01/stn6_incoming.wav",
	}
	self.SoundTbl_CallForHelp = {
		"vo/npc/female01/help01.wav",
		"vo/canals/arrest_helpme.wav",
	}
	self.SoundTbl_Suppressing = {}
	self.SoundTbl_WeaponReload = {
		"vo/npc/female01/coverwhilereload01.wav",
		"vo/npc/female01/coverwhilereload02.wav",
		"vo/npc/female01/gottareload01.wav",
	}
	self.SoundTbl_BeforeMeleeAttack = {}
	self.SoundTbl_MeleeAttack = {}
	self.SoundTbl_MeleeAttackExtra = {}
	self.SoundTbl_MeleeAttackMiss = {}
	self.SoundTbl_GrenadeAttack = {}
	self.SoundTbl_OnGrenadeSight = {
		"vo/npc/female01/getdown02.wav",
		"vo/npc/female01/gethellout.wav",
		"vo/npc/female01/runforyourlife01.wav",
		"vo/npc/female01/runforyourlife02.wav",
		"vo/npc/female01/strider_run.wav",
		"vo/npc/female01/takecover02.wav",
		"vo/npc/female01/uhoh.wav",
		"vo/npc/female01/watchout.wav",
	}
	self.SoundTbl_OnKilledEnemy = {
		"vo/npc/female01/gotone01.wav",
		"vo/npc/female01/gotone02.wav",
		"vo/npc/female01/likethat.wav",
		"vo/npc/female01/nice01.wav",
		"vo/npc/female01/nice02.wav",
		"vo/npc/female01/yeah02.wav",
		"vo/coast/odessa/female01/nlo_cheer01.wav",
		"vo/coast/odessa/female01/nlo_cheer02.wav",
		"vo/coast/odessa/female01/nlo_cheer03.wav",
	}
	self.SoundTbl_AllyDeath = {
		"vo/npc/female01/goodgod.wav",
		"vo/npc/female01/no01.wav",
		"vo/npc/female01/no02.wav",
		"vo/npc/female01/ohno.wav",
		"vo/coast/odessa/female01/nlo_cubdeath01.wav",
		"vo/coast/odessa/female01/nlo_cubdeath02.wav",
	}
	self.SoundTbl_Pain = {
		"vo/npc/female01/imhurt01.wav",
		"vo/npc/female01/imhurt02.wav",
		"vo/npc/female01/ow01.wav",
		"vo/npc/female01/ow02.wav",
		"vo/npc/female01/pain01.wav",
		"vo/npc/female01/pain02.wav",
		"vo/npc/female01/pain03.wav",
		"vo/npc/female01/pain04.wav",
		"vo/npc/female01/pain05.wav",
	}
	self.SoundTbl_DamageByPlayer = {
		"vo/npc/female01/onyourside.wav",
		"vo/npc/female01/stopitfm.wav",
		"vo/npc/female01/watchwhat.wav",
		"vo/trainyard/female01/cit_hit01.wav",
		"vo/trainyard/female01/cit_hit02.wav",
		"vo/trainyard/female01/cit_hit03.wav",
		"vo/trainyard/female01/cit_hit04.wav",
		"vo/trainyard/female01/cit_hit05.wav",
	}
	self.SoundTbl_Death = {
		"vo/npc/female01/pain06.wav",
		"vo/npc/female01/pain07.wav",
		"vo/npc/female01/pain08.wav",
		"vo/npc/female01/pain09.wav",
	}

	--[[ CUSTOM CODE

	]]--


	--[[ UNUSED

	-- Give player ammo
	vo/npc/female01/ammo01.wav    1 - 5

	-- Pick-up weapon
	vo/npc/female01/fantastic01.wav
	vo/npc/female01/fantastic02.wav
	vo/npc/female01/finally.wav
	vo/npc/female01/nice01.wav
	vo/npc/female01/nice02.wav
	vo/npc/female01/thislldonicely01.wav

	-- Alert player of danger
	vo/npc/female01/lookoutfm01.wav
	vo/npc/female01/lookoutfm02.wav
	vo/npc/female01/behindyou01.wav
	vo/npc/female01/behindyou02.wav

	-- Player died
	vo/npc/female01/gordead_ans01.wav        1 - 20
	vo/npc/female01/gordead_ques01.wav    1 - 17

	-- Vortigaunt Answer and Question
	vo/npc/female01/vanswer01.wav		1 - 14
	vo/npc/female01/vquestion01.wav		1 - 7

	-- Follow player not moving
	vo/npc/female01/waitingsomebody.wav

	vo/npc/female01/busy02.wav

	-- Supplies
	vo/npc/female01/cit_dropper01.wav
	vo/npc/female01/cit_dropper04.wav
	
	vo/npc/female01/moan01.wav		1 - 5
	
	vo/npc/female01/squad_approach01.wav
	vo/npc/female01/squad_away01.wav
	vo/npc/female01/squad_away03.wav
	vo/npc/female01/squad_follow01.wav
	vo/npc/female01/squad_follow02.wav
	vo/npc/female01/squad_follow04.wav
	vo/npc/female01/squad_greet02.wav
	vo/npc/female01/squad_reinforce_group01.wav		1 - 4
	vo/npc/female01/squad_reinforce_single01.wav	1 - 4
	
	vo/canals/female01/gunboat_breakcamp.wav
	vo/canals/female01/gunboat_eliright.wav
	vo/canals/female01/gunboat_hurry.wav
	vo/canals/female01/gunboat_justintime.wav
	vo/canals/female01/gunboat_moveon.wav
	vo/canals/female01/gunboat_parkboat.wav
	vo/canals/female01/gunboat_pullout.wav
	vo/canals/female01/stn6_shellingus.wav
	]]--
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/