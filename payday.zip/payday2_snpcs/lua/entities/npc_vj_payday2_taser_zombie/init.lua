AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/payday2/halloween_units/halloween_taser_rebel.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 135
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.SightDistance = 10000000 -- How far it can see
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.Medic_SpawnPropOnHealModel = "models/payday2/equipments/first_aid_kit.mdl"
ENT.Medic_CheckDistance = 1000 -- How far does it check for allies that are hurt? | World units
ENT.HasGrenadeAttack = false -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "obj_vj_grenade"
ENT.EntitiesToNoCollide = {"obj_vj_payday2_taser"}
ENT.AnimTbl_GrenadeAttack = {ACT_RANGE_ATTACK_THROW} -- Grenade Attack Animations
ENT.GrenadeAttackAttachment = "anim_attachment_RH" -- The attachment that the grenade will spawn at, set to false to use a custom position instead
ENT.AnimTbl_MeleeAttack = {"vjseq_MeleeAttack01"} -- Melee Attack Animations
ENT.AnimTbl_WeaponAttackSecondary = {"shoot_ar2_alt"} -- Animations played when the SNPC fires a secondary weapon attack
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 1 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/police/medic/onhelp/123648013.english.mp3","payday2/voices/police/medic/onhelp/142637101.english.mp3","payday2/voices/police/medic/onhelp/287516577.english.mp3","payday2/voices/police/medic/onhelp/33768141.english.mp3"}
ENT.SoundTbl_Alert = {"payday2/voices/police/taser/enemyfound/target-02.mp3","payday2/voices/police/taser/enemyfound/target-05.mp3","payday2/voices/police/taser/enemyfound/target-11.mp3","payday2/voices/police/taser/enemyfound/target-25.mp3","payday2/voices/police/taser/enemyfound/target-42.mp3","taser/Taser_Murpy.wav"}
ENT.SoundTbl_Pain = {"vjpayday2police/taser/die12.wav","vjpayday2police/taser/die2.wav","vjpayday2police/taser/die3.wav"}
ENT.SoundTbl_Death = {"payday2/voices/police/taser/death/death-01.mp3","payday2/voices/police/taser/death/death-03.mp3","payday2/voices/police/taser/death/death-07.mp3","payday2/voices/police/taser/death/death-15.mp3","payday2/voices/police/taser/death/death-18.mp3"}

ENT.GeneralSoundPitch1 = 70
ENT.GeneralSoundPitch2 = 70

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.Helmet2 = false
ENT.Helmet1 = false
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
		self.CanUseSecondaryOnWeaponAttack = true
		local rand1 = math.random(1,6)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/police/taser/spawn/move-01.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/police/taser/spawn/move-03.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/police/taser/spawn/move-05.mp3")
	end
		if rand1 == 4 then
	self:EmitSound("payday2/voices/police/taser/spawn/move-37.mp3")
	end
		if rand1 == 5 then
	self:EmitSound("payday2/voices/police/taser/spawn/move-43.mp3")
	end
		if rand1 == 6 then
	self:EmitSound("taser/Taser_Elec_Man.wav")
	end
	self.Helmet1 = true
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_CHEST then
		dmginfo:ScaleDamage(0.7)
	end
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(2)
	end
	if hitgroup == HITGROUP_HEAD && self.Helmet1 == true then
local effectdata = EffectData()
effectdata:SetOrigin(dmginfo:GetDamagePosition())
 util.Effect( "StunstickImpact", effectdata )  
  VJ_EmitSound(self,"n_ricochet_"..math.random(1,2)..".wav",90,100)
	dmginfo:ScaleDamage(0.4)
	self:SetBodygroup(1,1)
	self.hel1 = ents.Create("prop_physics")
	self.hel1:SetModel("models/payday2/helmets/taser.mdl")
	self.hel1:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.hel1:SetMaterial("models/payday2/halloween_units/taser/helmets_heavy_taser_atlas_hvh_df")
	self.hel1:SetPos(self:GetPos() +self:GetUp()*68 +self:GetRight()*0.1 +self:GetForward()*1)
	self.hel1:SetAngles(self:GetAngles())
	self.hel1:Spawn()
	self.hel1:Activate()
	self.Helmet1 = false
	end
	if hitgroup == HITGROUP_HEAD && self.Helmet2 == true then
	self:SetBodygroup(1,2)
	self.hel2 = ents.Create("prop_physics")
	self.hel2:SetModel("models/payday2/helmets/blue_swat.mdl")
	self.hel2:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.hel2:SetPos(self:GetPos() +self:GetUp()*68 +self:GetRight()*0.1 +self:GetForward()*1)
	self.hel2:SetAngles(self:GetAngles())
	self.hel2:SetBodygroup(0,1)
	self.hel2:Spawn()
	self.hel2:Activate()
	self.Helmet2 = false
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/