AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/shaklin/payday2/pd2_hoxton.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 1000000
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_PLAYER_ALLY"} -- NPCs with the same class with be allied to each other
ENT.FriendsWithAllPlayerAllies = true -- Should this SNPC be friends with all other player allies that are running on VJ Base?
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.HasMeleeAttack = true -- Should the SNPC have a melee attack?
ENT.AnimTbl_MeleeAttack = {"vjseq_MeleeAttack01"} -- Melee Attack Animations
ENT.Medic_SpawnPropOnHeal = false -- Should it spawn a prop, such as small health vial at a attachment when healing an ally?
ENT.IsMedicSNPC = true
ENT.TimeUntilMeleeAttackDamage = 0.7 -- This counted in seconds | This calculates the time until it hits something
ENT.MeleeAttackDamage = 25
ENT.Medic_HealthAmount = 1000000 -- How health does it give?
ENT.GodMode = false
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.GrenadeAttackAttachment = "chest" -- The attachment that the grenade will spawn at, set to false to use a custom position instead
ENT.GrenadeAttackSpawnPosition = Vector(20,0,15) -- The position to use if the attachment variable is set to false for spawning
ENT.HasGrenadeAttack = true -- Should the SNPC have a grenade attack?
ENT.AnimTbl_GrenadeAttack = {ACT_RANGE_ATTACK_THROW} -- Grenade Attack Animations
ENT.GrenadeAttackEntity = "cw_grenade_thrown"
ENT.TimeUntilGrenadeIsReleased = 0.87 -- Time until the grenade is released
ENT.BecomeEnemyToPlayer = true -- Should the friendly SNPC become enemy towards the player if it's damaged by a player?
ENT.AnimTbl_Medic_GiveHealth = {"heal"} -- Animations is plays when giving health to an ally
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {ACT_FLINCH_PHYSICS} -- If it uses normal based animation, use this
	-- ====== File Path Variables ====== --
	-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/houston/inspire_help/43706385.1.mp3","payday2/voices/houston/inspire_help/45417323.1.mp3"}
ENT.SoundTbl_GrenadeAttack = {"payday2/voices/houston/grenade/286523145.english.mp3","payday2/voices/houston/grenade/376560210.english.mp3","payday2/voices/houston/grenade/447437599.english.mp3"}
ENT.SoundTbl_Pain = {"payday2/pain/00ebacb9.mp3","payday2/pain/0457c4e2.mp3","payday2/pain/0905bc11.mp3"}
ENT.SoundTbl_Death = {"payday2/voices/police/regular/death/1003011234.1.mp3","payday2/voices/police/regular/death/15237935.1.mp3","payday2/voices/police/regular/death/18281706.1.mp3","payday2/voices/police/regular/death/38050603.1.mp3","payday2/voices/police/regular/death/45543700.1.mp3","payday2/voices/police/regular/death/66572380.1.mp3","payday2/voices/police/regular/death/685485541.1.mp3"}
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnMedic_BeforeHeal()
	timer.Simple(0.5,function() if IsValid(self) then 
local boneid = self:LookupBone( "ValveBiped.Bip01_L_Hand" )
local matrix = self:GetBoneMatrix( boneid )

self.m = ents.Create( "base_anim" )
self.m:SetModel( "models/payday2/equipments/first_aid_kit.mdl" )
self.m:SetPos(self:GetPos() +self:GetForward()*3 +self:GetRight()*-0.1 +self:GetUp())
self.m:SetAngles(self:GetAngles()+Angle(0,0,90))
self.m:SetParent( self )
self.m:SetOwner( self )
self.m:Spawn()
self.m:Activate()
self.m:FollowBone( self, boneid )
end end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink_AIEnabled()
	if IsValid(self:GetActiveWeapon()) && self:GetActiveWeapon().HoldType == "smg" then
		self.AnimTbl_IdleStand = {self:GetSequenceActivity(self:LookupSequence("Idle_Alert_SMG1_1"))}
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAlert(argent)
	if math.random(1,1) == 1 && argent:IsNPC() then
		//print(argent:Classify())
		if argent.HLR_Type == "Bulldozer" or argent:GetClass() == "npc_vj_payday2_bulldozer" or argent:GetClass() == "npc_vj_payday2_bulldozer_frag" or argent:GetClass() == "npc_vj_payday2_bulldozer_medic" or argent:GetClass() == "npc_vj_payday2_bulldozer_minigun" or argent:GetClass() == "npc_vj_payday2_bulldozer_saiga12k" or argent:GetClass() == "npc_vj_payday2_bulldozer_saw" or argent:GetClass() == "npc_vj_payday2_captain_dozer" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer_frag" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer_medic" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer_minigun" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer_saiga12k" or argent:GetClass() == "npc_vj_payday2_zeal_bulldozer_saw" or argent:GetClass() == "npc_vj_payday2_bulldozer_murkywater" or argent:GetClass() == "npc_vj_payday2_bulldozer_murkywater_saiga12k" or argent:GetClass() == "npc_vj_payday2_bulldozer_murkywater_saw" or argent:GetClass() == "npc_vj_payday2_bulldozer_policia" or argent:GetClass() == "npc_vj_payday2_bulldozer_medic_policia" or argent:GetClass() == "npc_vj_payday2_bulldozer_policia_minigun" or argent:GetClass() == "npc_vj_payday2_bulldozer_policia_saiga12k" or argent:GetClass() == "npc_vj_payday2_bulldozer_policia_saw" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/bulldozer/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/bulldozer/2.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/marks/bulldozer/3.mp3")
	end
		elseif argent.HLR_Type == "Civilian" or argent:GetClass() == "npc_vj_payday2_civilian" or argent:GetClass() == "npc_vj_payday2_scientist" or argent:GetClass() == "npc_vj_payday2_nurse" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/civilians/getdown/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/civilians/getdown/2.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/civilians/getdown/4.mp3")
	end
		elseif argent.HLR_Type == "Medic" or argent:GetClass() == "npc_vj_payday2_medic" or argent:GetClass() == "npc_vj_payday2_medic_murkywater" or argent:GetClass() == "npc_vj_payday2_medic_policia" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/medic/479513066.english.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/medic/574760162.english.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/marks/medic/694140779.english.mp3")
	end
		elseif argent.HLR_Type == "Sniper" or argent:GetClass() == "npc_vj_payday2_swat_sniper" or argent:GetClass() == "npc_vj_payday2_fbi_sniper" or argent:GetClass() == "npc_vj_payday2_fbi_sniper_murkywater" or argent:GetClass() == "npc_vj_payday2_swat_sniper_policia" then
		local rand1 = math.random(1,2)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/sniper/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/sniper/2.mp3")
	end
		elseif argent.HLR_Type == "Cloaker" or argent:GetClass() == "npc_vj_payday2_cloaker" or argent:GetClass() == "npc_vj_payday2_zeal_cloaker" or argent:GetClass() == "npc_vj_payday2_cloaker_murkywater" or argent:GetClass() == "npc_vj_payday2_cloaker_policia" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/cloaker/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/cloaker/2.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/marks/cloaker/3.mp3")
	end
		elseif argent.HLR_Type == "Shield" or argent:GetClass() == "npc_vj_payday2_swat_shield" or argent:GetClass() == "npc_vj_payday2_heavy_swat_shield" or argent:GetClass() == "npc_vj_payday2_fbi_shield" or argent:GetClass() == "npc_vj_payday2_heavy_fbi_shield" or argent:GetClass() == "npc_vj_payday2_zeal_swat_shield" or argent:GetClass() == "npc_vj_payday2_swat_shield_murkywater" or argent:GetClass() == "npc_vj_payday2_heavy_swat_shield_murkywater" or argent:GetClass() == "npc_vj_payday2_fbi_shield_murkywater" or argent:GetClass() == "npc_vj_payday2_heavy_fbi_shield_murkywater" or argent:GetClass() == "npc_vj_payday2_swat_shield_policia" or argent:GetClass() == "npc_vj_payday2_heavy_swat_shield_policia" or argent:GetClass() == "npc_vj_payday2_captain_guard_murkywater" or argent:GetClass() == "npc_vj_payday2_captain_guard" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/shield/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/shield/2.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/marks/shield/3.mp3")
	end
		elseif argent.HLR_Type == "Taser" or argent:GetClass() == "npc_vj_payday2_taser" or argent:GetClass() == "npc_vj_payday2_zeal_taser" or argent:GetClass() == "npc_vj_payday2_taser_murkywater" or argent:GetClass() == "npc_vj_payday2_taser_policia" then
		local rand1 = math.random(1,3)
		if rand1 == 1 then
	self:EmitSound("payday2/voices/houston/marks/taser/1.mp3")
	end
		if rand1 == 2 then
	self:EmitSound("payday2/voices/houston/marks/taser/2.mp3")
	end
		if rand1 == 3 then
	self:EmitSound("payday2/voices/houston/marks/taser/3.mp3")
	end
		end
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnMedic_OnReset()
	if IsValid(self) && IsValid(self.m) then self.m:Remove() end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(0.1)
	end
		dmginfo:ScaleDamage(0.3)
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/