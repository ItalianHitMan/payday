AddCSLuaFile("shared.lua")
include("shared.lua")
ENT.Model = {"models/pac/default.mdl"}
ENT.MoveCollideType = nil
ENT.CollisionGroupType = nil
ENT.SolidType = SOLID_VPHYSICS
ENT.RemoveOnHit = true
ENT.DoesRadiusDamage = true
ENT.RadiusDamageRadius = 10
ENT.RadiusDamage = 5
ENT.RadiusDamageUseRealisticRadius = false
ENT.RadiusDamageType = DMG_BURN
ENT.RadiusDamageForce = 0
ENT.DecalTbl_DeathDecals = {""}


ENT.FussTime = 0.5
ENT.TimeSinceSpawn = 0
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomPhysicsObjectOnInitialize(phys)
	phys:Wake()
	phys:EnableGravity(false)
	phys:SetBuoyancyRatio(0)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetMaterial("Invisible")
	//if self:GetOwner():IsValid() && (self:GetOwner().GrenadeAttackFussTime) then
	//timer.Simple(self:GetOwner().GrenadeAttackFussTime,function() if IsValid(self) then self:DeathEffects() end end) else
	timer.Simple(self.FussTime,function() if IsValid(self) then self:DeathEffects() end end)
	//end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnThink()
	self.TimeSinceSpawn = self.TimeSinceSpawn + 0.2
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage(dmginfo)
	self:GetPhysicsObject():AddVelocity(dmginfo:GetDamageForce() * 0.1)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPhysicsCollide(data,phys)
	self:DeathEffects()
end
---------------------------------------------------------------------------------------------------------------------------------------------
local function simplifyangle(angle)
	while(angle>=180) do
		angle = angle - 360;
	end
	while(angle <= -180) do
		angle = angle + 360;
	end
	return angle;
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:DeathEffects()
	if self:IsValid() then end

	self.stun_radius = 100

	local stunget = ents.FindInSphere(self:GetPos(),self.stun_radius)
	for k,v in ipairs(stunget) do
	local get_owner = self:GetOwner() != v
	if v:IsPlayer() then
	if v:Alive() then
	local tr = util.TraceLine({
		start = v:GetShootPos(),
		endpos = self.Entity:GetPos(),
		filter = v
	})
	local ang = (self.Entity:GetPos() - v:GetShootPos()):GetNormalized():Angle()
	local p = simplifyangle(ang.p - v:EyeAngles().p);
	local y = simplifyangle(ang.y - v:EyeAngles().y);
	local d = v:GetShootPos():Distance( self:GetPos() )
	local trres = v:GetEyeTrace()
           	if trres.HitWorld and !tr.HitWorld then
			if (  p > -45 && p < 45 && y > -45 && y < 45 ) || (v:GetEyeTrace() && v:GetEyeTrace() == self ) then
                    v:Ignite(8)
			else
                    v:Ignite(8)
			end
		end
	end
	end
	if v:IsNPC() and get_owner then
                    v:Ignite(8)
	end
	end

	self.ExplosionLight1 = ents.Create("light_dynamic")
	self.ExplosionLight1:SetKeyValue("brightness", "8")
	self.ExplosionLight1:SetKeyValue("distance", "400")
	self.ExplosionLight1:SetLocalPos(self:GetPos())
	self.ExplosionLight1:SetLocalAngles( self:GetAngles() )
	self.ExplosionLight1:Fire("Color", "255 255 255")
	self.ExplosionLight1:SetParent(self)
	self.ExplosionLight1:Spawn()
	self.ExplosionLight1:Activate()
	self.ExplosionLight1:Fire("TurnOn", "", 0)
	self:DeleteOnRemove(self.ExplosionLight1)

	local stun_ef = ""
	local position = self:GetPos() + self:GetUp()*10 + self:GetForward()
	ParticleEffect(stun_ef,position,Angle(0,0,0),nil)

	VJ_EmitSound(self,self.SoundTbl_Explode,100,100)

	self:SetLocalPos(Vector(self:GetPos().x,self:GetPos().y,self:GetPos().z +4)) -- Because the entity is too close to the ground
	local tr = util.TraceLine({
	start = self:GetPos(),
	endpos = self:GetPos() - Vector(0, 0, 100),
	filter = self })
	util.Decal(VJ_PICKRANDOMTABLE(self.DecalTbl_DeathDecals),tr.HitPos+tr.HitNormal,tr.HitPos-tr.HitNormal)
	
	self:SetDeathVariablesTrue(nil,nil,false)
	self:Remove()
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2019 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/