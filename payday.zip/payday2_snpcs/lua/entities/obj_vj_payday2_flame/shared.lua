ENT.Type 			= "anim"
ENT.Base 			= "obj_vj_projectile_base"
ENT.PrintName		= "Flame"
ENT.Author 			= "Dr.HunterALolicon"
ENT.Contact 		= "https://steamcommunity.com/id/6601216/"
ENT.Information		= "Projectiles for NPC"
ENT.Category		= "Girl's Frontline Project"

ENT.Spawnable = true
ENT.AdminOnly = false

if (CLIENT) then
	local Name = "Flame"
	local LangName = "obj_vj_payday2_flame"
	language.Add(LangName, Name)
	killicon.Add(LangName,"HUD/killicons/default",Color(255,80,0,255))
	language.Add("#"..LangName, Name)
	killicon.Add("#"..LangName,"HUD/killicons/default",Color(255,80,0,255))
end