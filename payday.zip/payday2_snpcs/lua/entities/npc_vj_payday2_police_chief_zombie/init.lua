AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/payday2/halloween_units/halloween_cop_4_rebel.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want 
ENT.StartHealth = 55
ENT.HullType = HULL_HUMAN
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_UNITED_STATES"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "Red" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.MeleeAttackDamage = 10
ENT.SightDistance = 10000000 -- How far it can see
ENT.FindEnemy_UseSphere = true -- Should the SNPC be able to see all around him? (360) | Objects and walls can still block its sight!
ENT.FindEnemy_CanSeeThroughWalls = true -- Should it be able to see through walls and objects? | Can be useful if you want to make it know where the enemy is at all times
ENT.FootStepTimeRun = 0.25 -- Next foot step sound when it is running
ENT.FootStepTimeWalk = 0.5 -- Next foot step sound when it is walking
ENT.Medic_SpawnPropOnHealModel = "models/payday2/equipments/first_aid_kit.mdl"
ENT.HasGrenadeAttack = false -- Should the SNPC have a grenade attack?
ENT.GrenadeAttackEntity = "cw_flash_thrown"
ENT.AnimTbl_MeleeAttack = {"vjseq_MeleeAttack01"} -- Melee Attack Animations
ENT.HasOnPlayerSight = true -- Should do something when it sees the enemy? Example: Play a sound
ENT.OnPlayerSightDistance = 500 -- How close should the player be until it runs the code?
ENT.OnPlayerSightDispositionLevel = 1 -- 0 = Run it every time | 1 = Run it only when friendly to player | 2 = Run it only when enemy to player
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"npc/footsteps/hardboot_generic1.wav","npc/footsteps/hardboot_generic2.wav","npc/footsteps/hardboot_generic3.wav","npc/footsteps/hardboot_generic4.wav","npc/footsteps/hardboot_generic5.wav","npc/footsteps/hardboot_generic6.wav","npc/footsteps/hardboot_generic8.wav"}
ENT.SoundTbl_MedicBeforeHeal = {"payday2/voices/police/medic/onhelp/123648013.english.mp3","payday2/voices/police/medic/onhelp/142637101.english.mp3","payday2/voices/police/medic/onhelp/287516577.english.mp3","payday2/voices/police/medic/onhelp/33768141.english.mp3"}
ENT.SoundTbl_Alert = {"payday2/voices/police/regular/enemyfound/10680530.1.mp3","payday2/voices/police/regular/enemyfound/173638177.1.mp3","payday2/voices/police/regular/enemyfound/22673528.1.mp3","payday2/voices/police/regular/enemyfound/3529354.1.mp3","payday2/voices/police/regular/enemyfound/468709881.1.mp3","payday2/voices/police/regular/enemyfound/52090260.1.mp3","payday2/voices/police/regular/enemyfound/630502375.1.mp3","payday2/voices/police/regular/enemyfound/642233273.1.mp3","payday2/voices/police/regular/enemyfound/646540601.1.mp3","payday2/voices/police/regular/enemyfound/93064458.1.mp3"}
ENT.SoundTbl_CallForHelp = {"payday2/voices/police/regular/cover/663167685.1.mp3","payday2/voices/police/regular/cover/917901918.1.mp3","payday2/voices/police/regular/cover/654751639.1.mp3","payday2/voices/police/regular/cover/118896249.1.mp3"}
ENT.SoundTbl_WeaponReload = {"payday2/voices/police/regular/cover/1038869175.1.mp3","payday2/voices/police/regular/cover/126281640.1.mp3","payday2/voices/police/regular/cover/131075466.1.mp3","payday2/voices/police/regular/cover/31879248.1.mp3","payday2/voices/police/regular/cover/798237364.1.mp3","payday2/voices/police/regular/cover/8093501.1.mp3"}
ENT.SoundTbl_GrenadeAttack = {"payday2/voices/police/regular/flashbang/117766465.1.mp3","payday2/voices/police/regular/flashbang/119615441.1.mp3","payday2/voices/police/regular/flashbang/459426581.1.mp3","payday2/voices/police/regular/flashbang/729632569.1.mp3","payday2/voices/police/regular/flashbang/800057952.1.mp3","payday2/voices/police/regular/flashbang/884743354.1.mp3","payday2/voices/police/regular/flashbang/899408221.1.mp3","payday2/voices/police/regular/flashbang/96940088.1.mp3","payday2/voices/police/regular/flashbang/998288951.1.mp3"}
ENT.SoundTbl_Pain = {"payday2/voices/police/regular/death/880674776.1.mp3","payday2/voices/police/regular/death/87460061.1.mp3"}
ENT.SoundTbl_Death = {"payday2/voices/police/regular/death/1003011234.1.mp3","payday2/voices/police/regular/death/15237935.1.mp3","payday2/voices/police/regular/death/18281706.1.mp3","payday2/voices/police/regular/death/38050603.1.mp3","payday2/voices/police/regular/death/45543700.1.mp3","payday2/voices/police/regular/death/66572380.1.mp3","payday2/voices/police/regular/death/685485541.1.mp3"}

ENT.GeneralSoundPitch1 = 70
ENT.GeneralSoundPitch2 = 70

/*
-- NOTE: Number sounds aren't included here!

npc/combine_soldier/vo/apex.wav
npc/combine_soldier/vo/blade.wav
npc/combine_soldier/vo/dagger.wav
npc/combine_soldier/vo/degrees.wav
npc/combine_soldier/vo/designatetargetas.wav
npc/combine_soldier/vo/echo.wav
npc/combine_soldier/vo/extractoraway.wav
npc/combine_soldier/vo/extractorislive.wav
npc/combine_soldier/vo/fist.wav
npc/combine_soldier/vo/flaredown.wav
npc/combine_soldier/vo/flash.wav
npc/combine_soldier/vo/grid.wav
npc/combine_soldier/vo/gridsundown46.wav
npc/combine_soldier/vo/hammer.wav
npc/combine_soldier/vo/helix.wav
npc/combine_soldier/vo/hunter.wav
npc/combine_soldier/vo/hurricane.wav
npc/combine_soldier/vo/ice.wav
npc/combine_soldier/vo/ion.wav
npc/combine_soldier/vo/jet.wav
npc/combine_soldier/vo/judge.wav
npc/combine_soldier/vo/kilo.wav
npc/combine_soldier/vo/mace.wav
npc/combine_soldier/vo/meters.wav
npc/combine_soldier/vo/nomad.wav
npc/combine_soldier/vo/nova.wav
npc/combine_soldier/vo/overwatch.wav
npc/combine_soldier/vo/overwatchrequestskyshield.wav -- requesting sky support
npc/combine_soldier/vo/overwatchrequestwinder.wav
npc/combine_soldier/vo/phantom.wav
npc/combine_soldier/vo/quicksand.wav
npc/combine_soldier/vo/range.wav
npc/combine_soldier/vo/ranger.wav
npc/combine_soldier/vo/razor.wav
npc/combine_soldier/vo/reaper.wav
npc/combine_soldier/vo/ripcord.wav
npc/combine_soldier/vo/scar.wav
npc/combine_soldier/vo/slash.wav
npc/combine_soldier/vo/spear.wav
npc/combine_soldier/vo/stab.wav
npc/combine_soldier/vo/star.wav
npc/combine_soldier/vo/stinger.wav
npc/combine_soldier/vo/storm.wav
npc/combine_soldier/vo/sundown.wav
npc/combine_soldier/vo/sweeper.wav
npc/combine_soldier/vo/swift.wav
npc/combine_soldier/vo/sword.wav
npc/combine_soldier/vo/tracker.wav
npc/combine_soldier/vo/uniform.wav
npc/combine_soldier/vo/vamp.wav
npc/combine_soldier/vo/viscon.wav


-- Radio sounds (background)
npc/combine_soldier/vo/prison_soldier_activatecentral.wav
npc/combine_soldier/vo/prison_soldier_boomersinbound.wav
npc/combine_soldier/vo/prison_soldier_bunker1.wav
npc/combine_soldier/vo/prison_soldier_bunker2.wav
npc/combine_soldier/vo/prison_soldier_bunker3.wav
npc/combine_soldier/vo/prison_soldier_containd8.wav
npc/combine_soldier/vo/prison_soldier_fallback_b4.wav
npc/combine_soldier/vo/prison_soldier_freeman_antlions.wav
npc/combine_soldier/vo/prison_soldier_fullbioticoverrun.wav
npc/combine_soldier/vo/prison_soldier_leader9dead.wav
npc/combine_soldier/vo/prison_soldier_negativecontainment.wav
npc/combine_soldier/vo/prison_soldier_prosecuted7.wav
npc/combine_soldier/vo/prison_soldier_sundown3dead.wav
npc/combine_soldier/vo/prison_soldier_tohighpoints.wav
npc/combine_soldier/vo/prison_soldier_visceratorsa5.wav
*/
-- Custom
ENT.Helmet2 = false
ENT.Helmet1 = false
-------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetBodygroup(1,math.random(0,1))
	self:SetBodygroup(2,math.random(0,1))
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_BeforeDamage(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		dmginfo:ScaleDamage(2)
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/