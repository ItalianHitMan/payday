if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end
---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.Base 						= "weapon_vj_base"
SWEP.PrintName					= "L4D2 Pistol"
SWEP.Author 					= "DrVrej"
SWEP.Contact					= "http://steamcommunity.com/groups/vrejgaming"
SWEP.Purpose					= "This weapon is made for Players and NPCs"
SWEP.Instructions				= "Controls are like a regular weapon."
SWEP.Category					= "Left 4 Dead"
	-- Main Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.ViewModel					= "" -- The view model (First person)
SWEP.WorldModel					= "models/vjpayday2police/weapons/w_pist_glock18.mdl" -- The world model (Third person, when a NPC is holding it, on ground, etc.)
SWEP.HoldType 					= "pistol" -- List of holdtypes are in the GMod wiki
-- NPC Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.NPC_NextPrimaryFire 		= 0.20 -- Next time it can use primary fire
SWEP.NPC_CustomSpread	 		= 0.8
SWEP.NPC_HasReloadSound			= true -- Should it play a sound when the base detects the SNPC playing a reload animation?
SWEP.NPC_ReloadSound			= {"weapons/pistol/pistol_reload1.wav"} 


SWEP.Primary.Damage				= 4 -- Damage
SWEP.Primary.ClipSize			= 15 -- Max amount of bullets per clip
SWEP.Primary.Delay				= 0.25 -- Time until it can shoot again
SWEP.Primary.Automatic			= true -- Is it automatic?
SWEP.Primary.Ammo				= "Pistol" -- Ammo type
SWEP.Primary.Sound				= {"vjpayday2police/chimano.wav"}
SWEP.Primary.AllowFireInWater	= true -- If true, you will be able to use primary fire in water
SWEP.PrimaryEffects_MuzzleAttachment = 1
SWEP.PrimaryEffects_ShellAttachment = 2
SWEP.PrimaryEffects_ShellType = "VJ_Weapon_PistolShell1"

-- To allow only NPCs to use it:
SWEP.MadeForNPCsOnly 			= true -- Is this weapon meant to be for NPCs only?

-- OR Allow both players and NPCs to use this weapon:
SWEP.Spawnable					= false
SWEP.AdminOnly					= false -- Is this weapon admin only?


-- All functions and variables are located inside the base files. It can be found in the GitHub Repository: https://github.com/DrVrej/VJ-Base