if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end
---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.Base 						= "weapon_vj_base"
SWEP.PrintName					= "VJ DoI M2 Flamethrower"
SWEP.Author 					= "DrVrej"
SWEP.Contact					= "http://steamcommunity.com/groups/vrejgaming"
SWEP.Purpose					= "This weapon is made for Players and NPCs"
SWEP.Instructions				= "Controls are like a regular weapon."
SWEP.Category					= "VJ Base"
	-- NPC Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.NPC_NextPrimaryFire 		= 0.001 -- Next time it can use primary fire
SWEP.NPC_TimeUntilFire			= 0.001 -- How much time until the bullet/projectile is fired?
SWEP.MadeForNPCsOnly 			= true -- Is this weapon meant to be for NPCs only?
SWEP.NPC_BulletSpawnAttachment = "muzzle_flash" -- The attachment that the bullet spawns on, leave empty for base to decide!
	-- Main Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.WorldModel					= "models/w_doi_flammenwerfer.mdl"
SWEP.HoldType 					= "ar2"
SWEP.ViewModelFlip				= false -- Flip the model? Usally used for CS:S models
SWEP.Spawnable					= false
SWEP.AdminSpawnable				= false
-- Primary Fire ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.Primary.DisableBulletCode	= true -- The bullet won't spawn, this can be used when creating a projectile-based weapon
SWEP.Primary.AllowFireInWater	= false -- If true, you will be able to use primary fire in water
SWEP.Primary.ClipSize			= 999 -- Max amount of bullets per clip
SWEP.Primary.TakeAmmo	= 0 -- How much ammo should it take on each shot?
SWEP.Primary.Automatic			= true -- Is it automatic?
SWEP.Primary.Sound				= {"weapons/flamethrower/flamethrower_looping.mp3"}
SWEP.Primary.DistantSound	= {"weapons/flamethrower/flamethrower_looping.mp3"}
SWEP.PrimaryEffects_MuzzleFlash = false
SWEP.PrimaryEffects_SpawnShells = false
SWEP.Primary.DistantSoundLevel	= 0.01 -- Distant sound level
SWEP.Primary.DistantSoundVolume	= 0.01 -- Distant sound volume

SWEP.IsUsingFlame = false
SWEP.RangeAttackDamageDistance = 350
SWEP.NextDamageT = 0

SWEP.IsUsingFlame = false
SWEP.RangeAttackDamageDistance = 350
SWEP.NextDamageT = 0

function SWEP:CustomOnPrimaryAttack_BeforeShoot()
	if self.IsUsingFlame == false then
	local shoot_angle = Vector(0,0,0)
	if self.Owner:IsNPC() then
		if self.Owner:GetEnemy() != NULL && self.Owner:GetEnemy() != nil then
			shoot_angle = self.Owner:GetEnemy():GetPos() - self.Owner:GetPos() 

			shoot_angle = shoot_angle-- + Vector(math.random(-85,85),math.random(-85,85),math.random(-85,85))*(shoot_angle:Distance(Vector(0,0,0))/1500)

			shoot_angle:Normalize()

		else
			return
		end
	end
	local shoot_pos   = self.Owner:GetPos() + self.Owner:GetRight() * 5 + self.Owner:GetUp() * 50 + shoot_angle * 550
	local flamefx = EffectData()
	flamefx:SetOrigin(shoot_pos)
	flamefx:SetStart(self.Owner:GetShootPos())
	flamefx:SetAttachment(1)
	flamefx:SetEntity(self.Weapon)
	util.Effect("swep_flamethrower_flame2",flamefx,true,true)
		self.IsUsingFlame = true 
	end
	local pos = self:GetNWVector("VJ_CurBulletPos")
	local proj = ents.Create("obj_vj_payday2_flame")
	proj:SetPos(pos)
	proj:SetAngles(self:GetOwner():GetAngles())
	proj:SetOwner(self:GetOwner())
	proj:Spawn()
	proj:Activate()
	local phys = proj:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
		phys:SetVelocity(self:GetOwner():CalculateProjectile("Line", pos, self:GetOwner():GetEnemy():GetPos() + self:GetOwner():GetEnemy():OBBCenter(), 500))
	end
end

function SWEP:CustomOnInitialize() 
	self.IsUsingFlame = false
	self.Owner.Weapon_FiringDistanceFar = 299 -- How far away it can shoot
	self.Owner.Weapon_FiringDistanceClose = 10 -- How close until it stops shooting
	self.RangeAttackDamageDistance = 350
end

function SWEP:CustomOnNPC_ServerThink()
//if !IsValid(self.Owner:GetEnemy()) && self.IsUsingFlame then
        self.IsUsingFlame = false
        self:StopParticles()
	end
//end

function SWEP:CustomOnRemove() 
    self:StopParticles()
end