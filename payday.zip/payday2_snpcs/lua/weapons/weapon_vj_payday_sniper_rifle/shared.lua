if (!file.Exists("autorun/vj_base_autorun.lua","LUA")) then return end
---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.Base 						= "weapon_vj_base"
SWEP.PrintName					= "L4D2 SNiper Rifle"
SWEP.Author 					= "DrVrej"
SWEP.Contact					= "http://steamcommunity.com/groups/vrejgaming"
SWEP.Purpose					= "This weapon is made for Players and NPCs"
SWEP.Instructions				= "Controls are like a regular weapon."
SWEP.Category					= "left 4 Dead"
	-- Main Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.ViewModel					= "" -- The view model (First person)
SWEP.WorldModel					= "models/weapons/w_cstm_l96.mdl" -- The world model (Third person, when a NPC is holding it, on ground, etc.)
SWEP.HoldType 					= "ar2" -- List of holdtypes are in the GMod wiki
-- NPC Settings ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.NPC_NextPrimaryFire 		= 2.5 -- Next time it can use primary fire
SWEP.NPC_CustomSpread	 		= 0.1 -- This is added on top of the custom spread that's set inside the SNPC! | Starting from 1: Closer to 0 = better accuracy, Farther than 1 = worse accuracy
SWEP.NPC_TimeUntilFire	 		= 0.5
	-- World Model ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.WorldModel_Invisible = false -- Should the world model be invisible?
SWEP.WorldModel_UseCustomPosition = true -- Should the gun use custom position? This can be used to fix guns that are in the crotch
SWEP.WorldModel_CustomPositionAngle = Vector(-10,3,180)
SWEP.WorldModel_CustomPositionOrigin = Vector(-1,1,1)
-- Primary Fire ---------------------------------------------------------------------------------------------------------------------------------------------
SWEP.Primary.Damage				= 75 -- Damage
SWEP.Primary.PlayerDamage		= "Double" -- Only applies for players | "Same" = Same as self.Primary.Damage, "Double" = Double the self.Primary.Damage OR put a number to be different from self.Primary.Damage
SWEP.Primary.Force				= 8 -- Force applied on the object the bullet hits
SWEP.Primary.ClipSize			= 5 -- Max amount of bullets per clip
SWEP.Primary.Delay				= 2.5 -- Time until it can shoot again
SWEP.Primary.Automatic			= false -- Is it automatic?
SWEP.Primary.Ammo				= "SMG1" -- Ammo type
SWEP.Primary.Sound				= {"weapons/cw_l96/fire.wav"}
SWEP.Primary.HasDistantSound	= true -- Does it have a distant sound when the gun is shot?
SWEP.Primary.DistantSound				= {"vjpayday2police/sniper/echo1.wav"}
SWEP.PrimaryEffects_MuzzleAttachment = 1
SWEP.PrimaryEffects_ShellAttachment = 2
SWEP.PrimaryEffects_ShellType = "VJ_Weapon_RifleShell1"

-- To allow only NPCs to use it:
SWEP.MadeForNPCsOnly 			= true -- Is this weapon meant to be for NPCs only?

-- OR Allow both players and NPCs to use this weapon:
SWEP.Spawnable					= false
SWEP.AdminOnly					= false -- Is this weapon admin only?

if (CLIENT) then
	local aimPos = Vector(0,0,0)
	local aimAng = Angle(0,0,0)
	function SWEP:GetViewModelPosition(pos,ang)
		if !self:GetZoomed() then return pos,ang end

		ang:RotateAroundAxis(ang:Right(),aimAng.x)
		ang:RotateAroundAxis(ang:Up(),aimAng.y)
		ang:RotateAroundAxis(ang:Forward(),aimAng.z)

		pos = pos +aimPos.x *ang:Right()
		pos = pos +aimPos.y *ang:Up()
		pos = pos +aimPos.z *ang:Forward()

		return pos, ang
	end

	local LaserMaterial = Material("sprites/rollermine_shock")
	local SpriteMaterial = Material("particle/particle_glow_02")
	local useEnt = true

	function SWEP:CustomOnDrawWorldModel()
		if IsValid(self:GetOwner()) then
			local var = GetConVarNumber("vj_hlr2_csniper")
			local attach = self:GetAttachment(self:LookupAttachment("muzzle_flash"))
			local ud,lr = -180, 700
			local endPos = attach.Pos +attach.Ang:Forward() *10000 +attach.Ang:Up() *ud +attach.Ang:Right() *lr
			local ent = self:GetOwner():IsNPC() && self:GetOwner():GetNWEntity("enemy")
			if !self:GetOwner():IsNPC() then var = 1 end
			if var == 1 then
				endPos = attach.Pos +attach.Ang:Forward() *10000 +attach.Ang:Up() *ud +attach.Ang:Right() *lr
			else
				if IsValid(ent) then
					endPos = ent:GetPos() +ent:OBBCenter()
				end
			end
			local tr = util.TraceLine({
				start = attach.Pos,
				endpos = endPos,
				filter = self,
			})
			render.SetMaterial(LaserMaterial)
			render.DrawBeam(attach.Pos,tr.HitPos,5,0,5,Color(255,0,0,255))
			render.SetMaterial(SpriteMaterial)
			render.DrawSprite(attach.Pos,3,3,Color(255,0,0,255))
			if tr.Hit == true then
				render.SetMaterial(SpriteMaterial)
				render.DrawSprite(tr.HitPos,math.random(4,6),math.random(4,6),Color(255,0,0,255))
			end
		end
		return true
	end
end


